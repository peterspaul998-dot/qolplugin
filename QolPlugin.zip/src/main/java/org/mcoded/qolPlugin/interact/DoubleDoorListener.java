package org.mcoded.qolPlugin.interact;


import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.Door;
import org.bukkit.block.data.type.Gate;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

public class DoubleDoorListener implements Listener {

    private final FileConfiguration fileConfiguration;
    private static final BlockFace[] FACES = {BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST};

    public DoubleDoorListener(FileConfiguration fileConfiguration) {
        this.fileConfiguration = fileConfiguration;
    }

    @EventHandler
    public void onDoorInteract(PlayerInteractEvent event) {


        if (!fileConfiguration.getBoolean("double-doors")) return;

        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Block clickedBlock = event.getClickedBlock();
        if (clickedBlock == null || !clickedBlock.getType().name().endsWith("_DOOR")) return;
        if (!(clickedBlock.getBlockData() instanceof Door doorData)) return;


        Block bottomBlock = doorData.getHalf() == Door.Half.TOP ? clickedBlock.getRelative(BlockFace.DOWN) : clickedBlock;
        Door bottomDoorData = (Door) bottomBlock.getBlockData();

        boolean newOpenState = !bottomDoorData.isOpen();

        for (BlockFace face : FACES) {
            Block neighbor = bottomBlock.getRelative(face);

            if (neighbor.getType() == bottomBlock.getType()) {
                if (neighbor.getBlockData() instanceof Door neighborData) {

                    if (neighborData.getFacing() == bottomDoorData.getFacing() && neighborData.getHinge() != bottomDoorData.getHinge()) {

                        neighborData.setOpen(newOpenState);
                        neighbor.setBlockData(neighborData);
                        break;
                    }
                }
            }
        }
    }
    @EventHandler
    public void onFencGateInteract(PlayerInteractEvent event) {
        if (!fileConfiguration.getBoolean("double-doors")) return;

        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Block clickedBlock = event.getClickedBlock();
        if (clickedBlock == null || !clickedBlock.getType().name().endsWith("_FENCE_GATE")) return;
        if (!(clickedBlock.getBlockData() instanceof Gate gateData)) return;

        Block gate = clickedBlock;

        boolean newOpenState = !gateData.isOpen();

        for (BlockFace face : FACES) {
            Block neighbor = gate.getRelative(face);
            if (neighbor.getType() == gate.getType()) {
                if (neighbor.getBlockData() instanceof Gate neighborData) {
                    if (neighborData.getFacing() == gateData.getFacing()) {
                        neighborData.setOpen(newOpenState);
                        neighbor.setBlockData(neighborData);
                    }
                }
            }
        }
    }
}