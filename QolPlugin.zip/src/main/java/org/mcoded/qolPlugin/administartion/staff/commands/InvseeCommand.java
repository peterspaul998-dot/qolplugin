package org.mcoded.qolPlugin.administartion.staff.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.mcoded.qolPlugin.QolPlugin;
import org.mcoded.qolPlugin.commands.home.GUI.HomeGUI;

public class InvseeCommand implements CommandExecutor {

    private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
    private FileConfiguration config = plugin.config;

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!(sender instanceof Player player)) return false;

        if (!config.getBoolean("commands.staff.invsee")) {
            player.sendMessage(Component.text("Invsee Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (args.length != 1) {
            player.sendMessage(Component.text("Usage: /invsee <player>").color(NamedTextColor.RED));
            return false;
        }

        Player target = Bukkit.getPlayer(args[0]);
        PlayerInventory targetinv = target.getInventory();

        Inventory inv = Bukkit.createInventory(null, 6 * 9, Component.text(target.getName() + "´s Inventory"));
        inv.setContents(target.getInventory().getContents());

        for (int i = 36; i < 45; i++) {
            inv.setItem(i, HomeGUI.HOME_GUI.frameItem(Material.CYAN_STAINED_GLASS_PANE));
        }
        inv.setItem(45, targetinv.getHelmet());
        inv.setItem(46, targetinv.getChestplate());
        inv.setItem(47, targetinv.getLeggings());
        inv.setItem(48, targetinv.getBoots());
        inv.setItem(50, targetinv.getItemInOffHand());

        player.openInventory(inv);
        return true;
    }
}
