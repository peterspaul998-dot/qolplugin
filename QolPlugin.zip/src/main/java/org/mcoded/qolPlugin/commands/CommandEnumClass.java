package org.mcoded.qolPlugin.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;


public enum CommandEnumClass {

    commands;

    public String UsageConfigCommand() {

        return "Usage: /config <commands/recipe/get> <setting> <true/false>";
    }

    public boolean getCommandAllow(FileConfiguration config, String Command, CommandSender sender) {

        boolean bool = config.getBoolean("commands." + Command);

        if (!bool) sender.sendMessage(Component.text(Command + " Command is disabled").color(NamedTextColor.RED));
        return bool;
    }
}
