package org.mcoded.qolPlugin.commands.home.GUI;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemRarity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.QolPlugin;

import java.util.List;

public enum HomeGUI {


    HOME_GUI;

    private final QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);

    public int[] DoubleChestFrameSlots() {

        return new int[]{
                1, 2, 3, 4, 5, 6, 7, 8,
                9,                  17,
                18,                 26,
                27,                 35,
                36,                 44,
                45, 46, 47, 48, 49, 50, 51, 52, 53};
    }
    public int[] ChestFrameSlots() {

        return new int[]{1, 2, 3, 4, 5, 6, 7, 8,
                9, 17,
                18, 26,
                27, 35,
                36, 37, 38, 39, 40, 41, 42, 43, 44,};
    }

    public ItemStack frameItem(Material GlassPane) {
        ItemStack frameItem = new ItemStack(GlassPane);
        ItemMeta frameItemMeta = frameItem.getItemMeta();

        frameItemMeta.customName(Component.empty());

        frameItem.setItemMeta(frameItemMeta);

        return frameItem;
    }

    public ItemStack closeItem() {
        ItemStack closeItem = new ItemStack(Material.BARRIER);
        ItemMeta closeItemMeta = closeItem.getItemMeta();

        closeItemMeta.setEnchantmentGlintOverride(true);
        closeItemMeta.itemName(Component.text("Close").decorate(TextDecoration.BOLD).color(NamedTextColor.RED));
        closeItem.setItemMeta(closeItemMeta);

        return closeItem;
    }
    public ItemStack BackItem() {
        ItemStack closeItem = new ItemStack(Material.BARRIER);
        ItemMeta closeItemMeta = closeItem.getItemMeta();

        closeItemMeta.setEnchantmentGlintOverride(true);
        closeItemMeta.itemName(Component.text("Back").decorate(TextDecoration.BOLD).color(NamedTextColor.RED));
        closeItem.setItemMeta(closeItemMeta);

        return closeItem;
    }

    public ItemStack HomeSet() {
        ItemStack SetItem = new ItemStack(Material.RED_BED);
        ItemMeta meta = SetItem.getItemMeta();

        meta.setEnchantmentGlintOverride(true);
        meta.itemName(Component.text("Home Set").decorate(TextDecoration.BOLD, TextDecoration.UNDERLINED).color(NamedTextColor.GOLD));

        SetItem.setItemMeta(meta);

        return SetItem;
    }
    public ItemStack HomeTp() {
        ItemStack Item = new ItemStack(Material.ENDER_PEARL);
        ItemMeta meta = Item.getItemMeta();

        meta.setEnchantmentGlintOverride(true);
        meta.itemName(Component.text("Home Tp").decorate(TextDecoration.BOLD, TextDecoration.UNDERLINED).color(NamedTextColor.BLUE));

        Item.setItemMeta(meta);

        return Item;
    }
    public ItemStack Homes(int count) {
        ItemStack Item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = Item.getItemMeta();

        meta.setItemModel(NamespacedKey.minecraft("white_bed"));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(QolPlugin.HomeKey, PersistentDataType.STRING, "home");
        meta.itemName(Component.text(count));
        meta.customName(Component.text("Home " + count).decorate(TextDecoration.BOLD, TextDecoration.UNDERLINED).decoration(TextDecoration.ITALIC, false).color(NamedTextColor.AQUA));

        Item.setItemMeta(meta);

        return Item;
    }
    public ItemStack hometemplate(int count, Location loc, String desc, Component name, NamespacedKey key) {
        ItemStack Item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = Item.getItemMeta();

        key = (key != null) ? key : NamespacedKey.minecraft("red_bed");


        Component HomeName = (name != null) ? name : Component.text("Home " + count)
                .decorate(TextDecoration.BOLD, TextDecoration.UNDERLINED)
                .decoration(TextDecoration.ITALIC, false).color(NamedTextColor.AQUA);


        meta.setItemModel(key);
        meta.getPersistentDataContainer().set(QolPlugin.HomeKey, PersistentDataType.STRING, "home");
        meta.setEnchantmentGlintOverride(true);
        meta.itemName(Component.text(count));
        meta.customName(HomeName);
        meta.setRarity(ItemRarity.COMMON);
        meta.lore(List.of(
                Component.empty(),
                Component.text("Location: ").color(NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)
                        .append(Component.text(loc.getBlockX() + " " + loc.getBlockY() + " " + loc.getBlockZ()).color(NamedTextColor.GRAY).decorate(TextDecoration.BOLD)),
                Component.empty(),
                Component.text("Description: ").color(NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)
                        .append(Component.text(desc).color(NamedTextColor.BLUE)),
                Component.empty()
        ));

        Item.setItemMeta(meta);

        return Item;
    }
    public ItemStack emptyHome(int home) {
        ItemStack Item = new ItemStack(Material.BARRIER);
        ItemMeta meta = Item.getItemMeta();

        meta.setEnchantmentGlintOverride(true);
        meta.customName(Component.text("Home: " + home +  " is empty").decorate(TextDecoration.BOLD).decoration(TextDecoration.ITALIC, false).color(NamedTextColor.RED));
        meta.itemName(Component.text(home));

        Item.setItemMeta(meta);

        return Item;
    }
    public ItemStack SetDescription(int num) {
        ItemStack item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = item.getItemMeta();

        meta.itemName(Component.text(num));
        meta.setItemModel(NamespacedKey.minecraft("anvil"));
        meta.customName(Component.text("Set Description").decorate(TextDecoration.BOLD).color(NamedTextColor.BLUE).decoration(TextDecoration.ITALIC, false));
        meta.setEnchantmentGlintOverride(true);

        item.setItemMeta(meta);

        return item;
    }
    public ItemStack SaveEdit(int num) {
        ItemStack item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = item.getItemMeta();

        meta.setEnchantmentGlintOverride(true);
        meta.itemName(Component.text(num));
        meta.customName(Component.text("Save Settings").color(NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false));
        meta.setItemModel(NamespacedKey.minecraft("green_concrete"));

        item.setItemMeta(meta);

        return item;
    }
    public ItemStack DeletHome(int num) {
        ItemStack item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = item.getItemMeta();

        meta.setEnchantmentGlintOverride(true);
        meta.setItemModel(NamespacedKey.minecraft("red_concrete"));
        meta.itemName(Component.text(num));
        meta.customName(Component.text("Delete Home").color(NamedTextColor.RED).decorate(TextDecoration.UNDERLINED).decoration(TextDecoration.ITALIC, false));

        item.setItemMeta(meta);
        return item;
    }
    public ItemStack nextSite() {
        ItemStack item = new ItemStack(Material.ARROW);
        ItemMeta meta = item.getItemMeta();

        meta.setEnchantmentGlintOverride(true);
        meta.itemName(Component.text("Next Site").color(NamedTextColor.DARK_PURPLE));
        item.setItemMeta(meta);
        return item;
    }
    public ItemStack prevSite() {
        ItemStack item = new ItemStack(Material.ARROW);
        ItemMeta meta = item.getItemMeta();

        meta.setEnchantmentGlintOverride(true);
        meta.itemName(Component.text("Previous Site").color(NamedTextColor.DARK_BLUE));
        item.setItemMeta(meta);
        return item;
    }
    public ItemStack SetName(int home) {
        ItemStack item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = item.getItemMeta();

        meta.setEnchantmentGlintOverride(true);
        meta.setItemModel(NamespacedKey.minecraft("oak_sign"));
        meta.itemName(Component.text(home));
        meta.customName(Component.text("Set Home Name").color(NamedTextColor.DARK_GREEN)
                .decoration(TextDecoration.ITALIC, false));

        item.setItemMeta(meta);

        return item;
    }
    public ItemStack SetIcon(int Home) {
        ItemStack item = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = item.getItemMeta();

        meta.itemName(Component.text(Home));
        meta.setItemModel(NamespacedKey.minecraft("item_frame"));
        meta.setEnchantmentGlintOverride(true);
        meta.customName(Component.text("Set Icon").color(NamedTextColor.AQUA)
                .decoration(TextDecoration.ITALIC, false));

        item.setItemMeta(meta);

        return item;
    }
}
