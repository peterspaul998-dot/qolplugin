package org.mcoded.qolPlugin.commands.tpa.settings;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

public class SettingsGUI implements InventoryHolder {

    private FileConfiguration config;
    private Inventory inv;

    public SettingsGUI(FileConfiguration config) {
        this.config = config;
    }

    public void SettingsOpen(Player player) {

        inv = Bukkit.createInventory(this, 5 * 9, Component.text(player.getName() + "´s Settings"));

        for (int slot : GuiItems.gui.ChestFrameSlots()) {
            inv.setItem(slot, GuiItems.gui.frameItem(Material.BLUE_STAINED_GLASS_PANE));
        }

        inv.setItem(0, GuiItems.gui.closeItem());

        inv.setItem(21, GuiItems.gui.Tpa(config, player));
        inv.setItem(23, GuiItems.gui.TpAuto(config, player));


        player.openInventory(inv);
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inv;
    }
}
