package org.mcoded.qolPlugin.maintanence;

import com.destroystokyo.paper.event.server.PaperServerListPingEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mcoded.qolPlugin.QolPlugin;
import org.mcoded.qolPlugin.commands.CommandEnumClass;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.zip.GZIPOutputStream;

public class MaintenanceCommand implements CommandExecutor, TabCompleter, Listener {

    private final FileConfiguration config;
    private final File file;
    private final World world;
    private final FileConfiguration conf;
    private FileConfiguration Worldconfig = JavaPlugin.getPlugin(QolPlugin.class).mcWorldConfig;

    public MaintenanceCommand(FileConfiguration file, File fil, FileConfiguration configuration) {
        config = file;
        this.file = fil;
        world = JavaPlugin.getPlugin(QolPlugin.class).chillWorld;
        this.conf = configuration;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {

        if (conf.get("commands.maintenance").equals(false)) {
            sender.sendMessage(Component.text("Maintenance Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (args.length == 0) {
            sender.sendMessage(Component.text("Usage: /maintenance <on/off/method>").color(NamedTextColor.RED));
            return false;
        }

        if (!args[0].equalsIgnoreCase("method") && args.length != 1) {
            sender.sendMessage(Component.text("Usage: /maintenance <on/off/method>").color(NamedTextColor.RED));
            return false;
        }

           switch (args[0]) {

               case "on" -> {

                   sender.sendMessage(Component.text("Maintenance Mode on").color(NamedTextColor.GREEN));

                   config.set("maintenance", true);

                   if (config.getString("method").equalsIgnoreCase("ChillWorld")) this.PlayerSave();
                   if (config.getString("method").equalsIgnoreCase("kick")) this.PlayerKick();


                   try {
                       config.save(file);
                   } catch (IOException e) {
                       e.printStackTrace();
                   }

                   return true;
               }

               case "off" -> {

                   if (!config.getBoolean("maintenance")) return false;

                   config.set("maintenance", false);

                   if (config.getString("method").equalsIgnoreCase("ChillWorld")) this.PlayerLoad();


                   sender.sendMessage(Component.text("Maintenance Mode off").color(NamedTextColor.RED));

                   try {
                       config.save(file);
                   } catch (IOException e) {
                       e.printStackTrace();
                   }

                   return true;
               }

               case "method" -> {
                   switch (args[1]) {
                       case "ChillWorld" -> {
                           config.set("method", "ChillWorld");
                           sender.sendMessage(Component.text("The Maintenance Method has been set to ").color(NamedTextColor.GREEN)
                                   .append(Component.text("ChillWorld").decorate(TextDecoration.BOLD)));
                       }
                       case "None" -> {
                           config.set("method", "None");
                           sender.sendMessage(Component.text("The Maintenance Method has been set to ").color(NamedTextColor.GREEN)
                                   .append(Component.text("None").decorate(TextDecoration.BOLD)));
                       }
                       case "Kick" -> {
                           config.set("method", "Kick");
                           sender.sendMessage(Component.text("The Maintenance Method has been set to ").color(NamedTextColor.GREEN)
                                   .append(Component.text("Kick").decorate(TextDecoration.BOLD)));
                       }
                   }
                   try {
                       config.save(file);
                   } catch (IOException e) {
                       e.printStackTrace();
                   }
                   return true;
               }
           }

        sender.sendMessage(Component.text("Usage: /maintenance <on/off/method>").color(NamedTextColor.RED));

        return true;
    }

    public void PlayerSave() {
        for (Player players : Bukkit.getOnlinePlayers()) {
            if (players.isOp()) continue;
            if (players.getLocation().getWorld().equals(JavaPlugin.getPlugin(QolPlugin.class).chillWorld)) continue;
            // if (config.get("players." + players.getUniqueId()) != null && config.getBoolean("maintenance")) continue;

            players.addPotionEffect(new PotionEffect(
                    PotionEffectType.RESISTANCE,
                    -1,
                    5,
                    false,

                    false

            ));

            config.set("players." + players.getUniqueId() + ".inv", players.getInventory().getContents());
            players.getInventory().setContents(new ItemStack[]{});

            config.set("players." + players.getUniqueId() + ".loc", players.getLocation());
            config.set("players." + players.getUniqueId() + ".gamemode", players.getGameMode().toString());

            players.setGameMode(gamemode());

            players.teleport(JavaPlugin.getPlugin(QolPlugin.class).chillWorld.getSpawnLocation());
            players.sendMessage(Component.text("The Server is currently under maintenance please wait until the Server is open").color(NamedTextColor.RED).decorate(TextDecoration.BOLD));
        }
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void PlayerLoad() {

        for (Player players : Bukkit.getOnlinePlayers()) {
            if (players.isOp()) continue;

            Object obj = config.get("players." + players.getUniqueId() + ".inv");

            if (obj instanceof List<?> list) {
                ItemStack[] items = list.toArray(new ItemStack[0]);
                players.getInventory().setContents(items);

            } else if (obj instanceof ItemStack[] array) {
                players.getInventory().setContents(array);
            }
            players.teleport(config.getLocation("players." + players.getUniqueId() + ".loc", Bukkit.getWorld("world").getSpawnLocation()));

            players.setGameMode(GameMode.valueOf(config.getString("players." + players.getUniqueId() + ".gamemode", "survival")));
            players.removePotionEffect(PotionEffectType.RESISTANCE);
            players.sendMessage(Component.text("The Server is Open").color(NamedTextColor.GREEN).decorate(TextDecoration.BOLD));
            config.set("players." + players.getUniqueId(), null);
        }
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();

        }
    }
    public void SinglePlayerLoad(Player players) {
        if (players.isOp()) return;

        Object obj = config.get("players." + players.getUniqueId() + ".inv");

        if (obj instanceof List<?> list) {
            players.sendMessage(("Obj: " + obj));
            players.sendMessage(("Class: " + (obj == null ? "null" : obj.getClass().getName())));
            ItemStack[] items = list.toArray(new ItemStack[0]);
            players.getInventory().setContents(items);

        } else if (obj instanceof ItemStack[] array) {
            players.getInventory().setContents(array);
        }

        Location location = config.getLocation("players." + players.getUniqueId() + ".loc", Bukkit.getWorld("world").getSpawnLocation());
        players.sendMessage(("Location: " + location));

        players.teleport(location);


        players.setGameMode(GameMode.valueOf(config.getString("players." + players.getUniqueId() + ".gamemode", "survival")));
        players.removePotionEffect(PotionEffectType.RESISTANCE);
        players.sendMessage(Component.text("The Server is Open").color(NamedTextColor.GREEN).decorate(TextDecoration.BOLD));
        config.set("players." + players.getUniqueId(), null);
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    public void PlayerKick() {

        for (Player players : Bukkit.getOnlinePlayers()) {
            if (players.isOp()) return;

            players.kick(Component.text("The Server is currently under maintenance please wait until the Server is open").color(NamedTextColor.RED).decorate(TextDecoration.BOLD));
        }
    }

    public GameMode gamemode() {
        String Gamemode = Worldconfig.getString("gamemode", "adventure");
        if (Gamemode.equalsIgnoreCase("adventure")) return GameMode.ADVENTURE;
        if (Gamemode.equalsIgnoreCase("survival")) return GameMode.SURVIVAL;
        if (Gamemode.equalsIgnoreCase("creative")) return GameMode.CREATIVE;
        if (Gamemode.equalsIgnoreCase("spectator")) return GameMode.SPECTATOR;
        return GameMode.ADVENTURE;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();
        if (player.isOp()) return;

        if (!config.getBoolean("maintenance")) return;

        if (config.getString("method").equalsIgnoreCase("kick")) {
            this.PlayerKick();
        }
        if (config.getString("method").equalsIgnoreCase("ChillWorld")) {
            this.PlayerSave();
        }
    }
    // For the motd
    @EventHandler
    public void onPing(PaperServerListPingEvent e) {
        if (!config.getBoolean("maintenance")) return;

        e.motd(Component.text("The Server is currently under maintenance please wait until the Server is open")
                .color(NamedTextColor.RED));
        e.setVersion("Offline •");
        e.setProtocolVersion(-1);

    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (args.length == 1) return List.of("on", "off", "method".toLowerCase()).stream().filter(
                s -> s.startsWith(args[0])
        ).toList();
        if (args.length == 2 && args[0].equals("method")) return List.of("ChillWorld", "None", "Kick")
                .stream().filter(s -> s.startsWith(args[1])).toList();
        return List.of();
    }

}
