
package org.mcoded.qolPlugin.death;

import io.papermc.paper.datacomponent.item.ResolvableProfile;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Skull;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mcoded.qolPlugin.QolPlugin;
import org.mcoded.qolPlugin.commands.home.GUI.HomeGUI;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class DeathManager implements Listener, TabExecutor {

    private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);

    private final FileConfiguration config =
            plugin.config;

    public final HashMap<Location, Inventory> graveMap = new HashMap<>();

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {

        Player player = e.getPlayer();

        if (config.getBoolean("death.pos.enabled")) {

            Location loc = player.getLocation();

            String formatted = config.getString(
                            "death.pos.message",
                            "&7You have died from &c&l{reason}&r&7 at &1&l{x} {y} {z}&r&7 in the &d&l{dim}"
                    )
                    .replace("{x}", String.valueOf(loc.getBlockX()))
                    .replace("{y}", String.valueOf(loc.getBlockY()))
                    .replace("{z}", String.valueOf(loc.getBlockZ()))
                    .replace("{dim}", loc.getWorld().getName())
                    .replace(
                            "{reason}",
                            e.getDamageSource()
                                    .getDamageType()
                                    .getKey()
                                    .getKey()
                    );

            Component component =
                    LegacyComponentSerializer.legacyAmpersand()
                            .deserialize(formatted);

            player.sendMessage(component);
        }

        if (!config.getBoolean("death.grave.enabled")) {
            return;
        }
        if (e.getDrops().isEmpty()) return;
        /*
         * Wir verhindern die normalen Death-Drops.
         * Die Items werden anschließend aus dem Spielerinventar
         * in das Grave-Inventar kopiert.
         */
        e.getDrops().clear();

        createGraveStone(player, player.getLocation());
    }

    public void createGraveStone(Player player, Location location) {

        /*
         * Immer die Block-Koordinaten verwenden.
         * Dadurch haben wir für denselben Block immer exakt
         * dieselbe Location als HashMap-Key.
         */
        Location graveLocation = location.getBlock().getLocation();

        Block graveBlock = graveLocation.getBlock();

        /*
         * Falls an dieser Stelle bereits ein Grave existiert,
         * überschreiben wir ihn nicht.
         */
        if (graveMap.containsKey(graveLocation)) {
            return;
        }

        /*
         * Head setzen.
         */
        graveBlock.setType(Material.PLAYER_HEAD);

        /*
         * Profil auf den Skull setzen.
         */
        if (graveBlock.getState() instanceof Skull skull) {

            skull.setProfile(
                    ResolvableProfile.resolvableProfile(
                            player.getPlayerProfile()
                    )
            );

            skull.update(true, false);
        }

        /*
         * 54 Slots = 6 Reihen.
         */
        Inventory inventory = Bukkit.createInventory(
                null,
                9 * 6,
                player.getName() + "´s Inventory"
        );

        /*
         * Hauptinventar kopieren.
         *
         * Slots 0-35:
         * 0-8   Hotbar
         * 9-35  normales Inventar
         */
        ItemStack[] contents = player.getInventory().getContents();

        for (int i = 0; i < 36 && i < contents.length; i++) {

            ItemStack item = contents[i];

            if (item != null && item.getType() != Material.AIR) {
                inventory.setItem(i, item.clone());
            }
        }

        /*
         * Rüstung:
         *
         * Grave:
         * 45 = Boots
         * 46 = Leggings
         * 47 = Chestplate
         * 48 = Helmet
         */
        ItemStack[] armor = player.getInventory().getArmorContents();

        if (armor.length > 0 && armor[0] != null) {
            inventory.setItem(45, armor[0].clone());
        }

        if (armor.length > 1 && armor[1] != null) {
            inventory.setItem(46, armor[1].clone());
        }

        if (armor.length > 2 && armor[2] != null) {
            inventory.setItem(47, armor[2].clone());
        }

        if (armor.length > 3 && armor[3] != null) {
            inventory.setItem(48, armor[3].clone());
        }

        /*
         * Offhand.
         */
        ItemStack offHand = player.getInventory().getItemInOffHand();

        if (offHand != null && offHand.getType() != Material.AIR) {
            inventory.setItem(50, offHand.clone());
        }

        /*
         * Slots 36-39 werden nicht direkt als normale
         * Inventarslots verwendet.
         *
         * Deshalb werden diese Items nach 45-48 verschoben.
         *
         * Wir haben oben bereits das Armor-Inventory separat
         * behandelt, deshalb müssen wir hier nichts mehr verschieben.
         */

        /*
         * GUI-Rahmen.
         */
        for (int i = 36; i < 45; i++) {
            inventory.setItem(
                    i,
                    HomeGUI.HOME_GUI.frameItem(
                            Material.CYAN_STAINED_GLASS_PANE
                    )
            );
        }

        /*
         * Transfer-Button.
         */
        inventory.setItem(53, transferItems());

        /*
         * Erst nachdem das komplette Inventory erstellt wurde,
         * wird es in graveMap eingetragen.
         */
        graveMap.put(graveLocation, inventory);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {

        if (!e.getAction().isRightClick()) {
            return;
        }

        Block block = e.getClickedBlock();

        if (block == null) {
            return;
        }

        Location location = block.getLocation();

        Inventory grave = graveMap.get(location);

        /*
         * Kein Grave an dieser Position.
         */
        if (grave == null) {
            return;
        }

        /*
         * Andere Spieler dürfen den Grave öffnen.
         */
        if (config.getBoolean("death.grave.allow-other-players-open")) {

            e.setCancelled(true);
            e.getPlayer().openInventory(grave);
            return;
        }

        /*
         * Nur der Besitzer darf öffnen.
         */
        if (!(block.getState() instanceof Skull skull)) {
            return;
        }

        UUID uuid = e.getPlayer().getUniqueId();

        if (skull.getProfile() != null
                && skull.getProfile().uuid().equals(uuid)) {

            e.setCancelled(true);
            e.getPlayer().openInventory(grave);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {

        Location graveLocation = null;

        /*
         * Wir suchen den Grave, zu dem das geschlossene
         * Inventory gehört.
         */
        for (Map.Entry<Location, Inventory> entry : graveMap.entrySet()) {

            if (!entry.getValue().equals(e.getInventory())) {
                continue;
            }

            /*
             * WICHTIG:
             * Der Grave wird NICHT einfach beim Schließen gelöscht.
             *
             * Nur wenn wirklich keine Items mehr vorhanden sind,
             * wird der Grave entfernt.
             */
            if (isEmptyGrave(entry.getValue())) {
                graveLocation = entry.getKey();
            }

            break;
        }

        /*
         * Erst NACH der Schleife aus der Map entfernen.
         *
         * Dadurch vermeiden wir ConcurrentModificationException.
         */
        if (graveLocation != null) {

            Block block = graveLocation.getBlock();

            if (block.getType() == Material.PLAYER_HEAD) {
                block.setType(Material.AIR);
            }

            graveMap.remove(graveLocation);
        }
    }

    @EventHandler
    public void onWaterPlace(PlayerBucketEmptyEvent e) {
        if (!graveMap.containsKey(e.getBlock().getLocation())) return;

        e.setCancelled(true);
    }

    @EventHandler
    public void onWaterBreak(BlockFromToEvent e) {
        Block toBlock = e.getToBlock();

        if (toBlock.getType() == Material.PLAYER_HEAD || toBlock.getType() == Material.PLAYER_WALL_HEAD) {
            Block fromBlock = e.getBlock();

            if (fromBlock.getType() != Material.WATER) return;

            if (!graveMap.containsKey(toBlock.getLocation())) return;
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {

        Location location = e.getBlock().getLocation();

        /*
         * Graves dürfen nicht normal abgebaut werden.
         */
        if (graveMap.containsKey(location)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {

        if (!(e.getWhoClicked() instanceof Player player)) {
            return;
        }

        if (e.getClickedInventory() == null) {
            return;
        }

        ItemStack item = e.getCurrentItem();

        if (item == null || item.getType() == Material.AIR) {
            return;
        }

        if (!item.isSimilar(transferItems())) {
            return;
        }

        e.setCancelled(true);

        Inventory inv = e.getClickedInventory();
        PlayerInventory playerInv = player.getInventory();

        /*
         * Hauptinventar: 1:1 tauschen statt einsammeln.
         */
        for (int i = 0; i < 36; i++) {

            ItemStack graveItem = inv.getItem(i);
            ItemStack playerItem = playerInv.getItem(i);

            inv.setItem(i, playerItem == null ? null : playerItem.clone());
            playerInv.setItem(i, graveItem == null ? null : graveItem.clone());
        }

        /*
         * Rüstung + Offhand: ebenfalls tauschen statt nur übernehmen.
         */
        swapArmorSlot(inv, 45, playerInv::getBoots, playerInv::setBoots);
        swapArmorSlot(inv, 46, playerInv::getLeggings, playerInv::setLeggings);
        swapArmorSlot(inv, 47, playerInv::getChestplate, playerInv::setChestplate);
        swapArmorSlot(inv, 48, playerInv::getHelmet, playerInv::setHelmet);

        ItemStack graveOffhand = inv.getItem(50);
        ItemStack currentOffhand = playerInv.getItemInOffHand();

        inv.setItem(50, currentOffhand == null ? null : currentOffhand.clone());
        playerInv.setItemInOffHand(graveOffhand == null ? null : graveOffhand.clone());

        /*
         * GUI-Rahmen neu aufbauen.
         */
        for (int i = 36; i < 45; i++) {
            inv.setItem(i, HomeGUI.HOME_GUI.frameItem(Material.CYAN_STAINED_GLASS_PANE));
        }

        inv.setItem(53, transferItems());
        if (isEmptyGrave(inv)) player.closeInventory();
    }

    private void swapArmorSlot(Inventory grave, int slot,
                               Supplier<ItemStack> getCurrent,
                               Consumer<ItemStack> setCurrent) {

        ItemStack graveItem = grave.getItem(slot);
        ItemStack currentItem = getCurrent.get();

        grave.setItem(slot, currentItem == null ? null : currentItem.clone());
        setCurrent.accept(graveItem == null ? null : graveItem.clone());
    }

    public ItemStack transferItems() {

        ItemStack item = new ItemStack(Material.HOPPER);

        ItemMeta meta = item.getItemMeta();

        meta.itemName(
                Component.text("Switch your Inventory with the grave")
                        .color(NamedTextColor.BLUE)
        );

        meta.setEnchantmentGlintOverride(true);

        item.setItemMeta(meta);

        return item;
    }

    public boolean isEmptyGrave(Inventory inv) {

        /*
         * Wir prüfen alle Slots, die tatsächlich Items enthalten
         * können.
         *
         * Die GUI-Rahmen-Slots 36-44 und der Transfer-Button 53
         * werden absichtlich ignoriert.
         */

        // Hauptinventar
        for (int i = 0; i < 36; i++) {

            ItemStack item = inv.getItem(i);

            if (item != null
                    && item.getType() != Material.AIR) {

                return false;
            }
        }

        // Rüstung
        for (int i = 45; i <= 48; i++) {

            ItemStack item = inv.getItem(i);

            if (item != null
                    && item.getType() != Material.AIR) {

                return false;
            }
        }

        // Offhand
        ItemStack offHand = inv.getItem(50);

        if (offHand != null
                && offHand.getType() != Material.AIR) {

            return false;
        }

        return true;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!config.getBoolean("commands.staff.grave")) {
            sender.sendMessage(Component.text("Grave Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (args.length == 0) {
            sender.sendMessage(Component.text("Usage: /grave <remove/get>").color(NamedTextColor.RED));
            return false;
        }
        switch (args[0].toLowerCase()) {
            case "remove" -> {
                Component usage = Component.text("Usage: /grave remove <world> <x> <y> <z>").color(NamedTextColor.RED);
                if (args.length != 5) {
                    sender.sendMessage(usage);
                    return false;
                }
                World world = Bukkit.getWorld(args[1]);
                int x = 0;
                int y = 0;
                int z = 0;


                try {
                    x = Integer.parseInt(args[2]);
                    y = Integer.parseInt(args[3]);
                    z = Integer.parseInt(args[4]);
                } catch (Exception e) {
                    sender.sendMessage(usage);
                }

                if (world == null) {
                    sender.sendMessage(usage);
                    return false;
                }

                Location loc = new Location(world, x, y, z);

                if (!graveMap.containsKey(loc)) {
                    sender.sendMessage(Component.text("Gravestone doesn´t exist").color(NamedTextColor.RED));
                    return false;
                }

                graveMap.remove(loc);
                sender.sendMessage(Component.text(
                        "Gravestone removed in ")
                        .color(NamedTextColor.GREEN)
                        .append(Component.text(world.getName()).decorate(TextDecoration.BOLD))
                        .append(Component.text(" in "))
                        .append(Component.text(x + " " + y + " " + z).decorate(TextDecoration.BOLD)));
                loc.getBlock().setType(Material.AIR);
                return true;
            }

             case "get" -> {
                if (graveMap.isEmpty()) {
                    sender.sendMessage(Component.text("They are no graves").color(NamedTextColor.BLUE));
                }
                int start = 0;
                 for (Map.Entry<Location, Inventory> entry : graveMap.entrySet()) {
                    start = start + 1;
                     Location loc = entry.getKey();
                     sender.sendMessage(
                             Component.text(start + ". Grave is in ")
                                     .color(NamedTextColor.BLUE)
                                     .append(Component.text(loc.getWorld().getName()).decorate(TextDecoration.BOLD))
                                     .append(Component.text(" at "))
                                     .append(Component.text(loc.getBlockX() + " " + loc.getBlockY() + " " + loc.getBlockZ())
                                             .decorate(TextDecoration.BOLD))
                     );
                 }
                 return true;
            }

        }

        sender.sendMessage(Component.text("Usage: /grave <remove/get>").color(NamedTextColor.RED));
        return false;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (args.length == 1) return List.of("remove", "get").stream().filter(s -> s.startsWith(args[0])).toList();

        if (args.length == 2 && args[0].equalsIgnoreCase("remove")) return getWorlds()
                .stream().filter(s -> s.startsWith(args[1])).toList();

        if (args.length == 3 && args[0].equalsIgnoreCase("remove")) return List.of("<x>");
        if (args.length == 4 && args[0].equalsIgnoreCase("remove")) return List.of("<y>");
        if (args.length == 5 && args[0].equalsIgnoreCase("remove")) return List.of("<z>");

        return List.of();
    }

    private List<String> getWorlds() {
        List<String> list = new ArrayList<>(List.of());

        for (World world : Bukkit.getWorlds()) {
            list.add(world.getName());
        }
        return list;
    }
}
