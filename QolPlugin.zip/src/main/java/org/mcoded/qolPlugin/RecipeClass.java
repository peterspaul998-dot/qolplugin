package org.mcoded.qolPlugin;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.plugin.java.JavaPlugin;

public class RecipeClass {

    private final JavaPlugin plugin;
    private ShapedRecipe light;
    private final NamespacedKey lightkey;

    public RecipeClass(JavaPlugin plugin, String lightkey) {
        this.plugin = plugin;
        this.lightkey = new NamespacedKey(plugin, lightkey);
    }

    public void addLightRecipe() {
        light = new ShapedRecipe(lightkey, new ItemStack(Material.LIGHT));

        light.shape(
                "ggg",
                "glg",
                "ggg"
        );
        light.setIngredient('g', Material.GLOWSTONE_DUST);
        light.setIngredient('l', Material.LAVA_BUCKET);

        Bukkit.addRecipe(light);
    }

    public void removeLightRecipe() {
        Bukkit.removeRecipe(lightkey);
    }

}
