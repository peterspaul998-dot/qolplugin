package org.mcoded.qolPlugin.commands.quality;

import com.destroystokyo.paper.inventory.meta.ArmorStandMeta;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDismountEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.mcoded.qolPlugin.QolPlugin;

public class SitCommand implements CommandExecutor, Listener {

    private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
    private FileConfiguration config = plugin.config;


    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!config.getBoolean("commands.quality.sit")) {
            sender.sendMessage(Component.text("Sit Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (!(sender instanceof Player player)) return false;
        PlayerSit(player, player.getLocation().subtract(0, 1, 0));
        return true;
    }
    @EventHandler
    public void onDismount(EntityDismountEvent e) {
        if (!e.getDismounted().getScoreboardTags().contains("qolplugin.sit")) return;
        e.getEntity().teleport(e.getDismounted().getLocation().add(0, 1 ,0));
        e.getDismounted().remove();
    }
    public void PlayerSit(Player player, Location loc) {
        if (player.getVehicle() != null) {
            player.sendMessage(Component.text("You are already riding an Entity!").color(NamedTextColor.RED));
            return;
        }
        if (player.getWorld().getBlockAt(player.getLocation().subtract(0, 1, 0)).getType().equals(Material.AIR)) {
            player.sendMessage(Component.text("You need to stand on the Ground!").color(NamedTextColor.RED));
            return;
        }

        ArmorStand entity = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);

        entity.setGravity(false);
        entity.setInvulnerable(true);
        entity.setCustomNameVisible(false);
        entity.setInvisible(true);
        entity.setSmall(true);
        entity.addScoreboardTag("qolplugin.sit");

        entity.addPassenger(player);

    }
}
