package org.mcoded.qolPlugin.administartion.staff.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

public class GodCommand implements CommandExecutor {
    private final FileConfiguration config;

    public GodCommand(FileConfiguration config) {
        this.config = config;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!config.getBoolean("commands.staff.god")) {
            sender.sendMessage(Component.text("God Command is turned off").color(NamedTextColor.RED));
            return false;
        }
        if (!(sender instanceof Player player)) return false;

        if (!player.hasPotionEffect(PotionEffectType.RESISTANCE)) {
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.RESISTANCE,
                    -1,
                    5,
                    false,
                    false
            ));
        } else {
            player.removePotionEffect(PotionEffectType.RESISTANCE);
        }
        return true;
    }
}
