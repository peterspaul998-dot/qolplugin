package org.mcoded.qolPlugin.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.mcoded.qolPlugin.QolPlugin;

public class PingCommand implements CommandExecutor {

    private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
    private FileConfiguration config = plugin.config;

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
         if (!config.getBoolean("commands.ping")) {
            sender.sendMessage(Component.text("Ping Command is turned off").color(NamedTextColor.RED));
            return false;
        }
        if (!(sender instanceof Player player)) return false;

        player.sendMessage(Component.text("Your Ping is ").color(NamedTextColor.GRAY)
                .append(Component.text(player.getPing() + "ms").color(NamedTextColor.GREEN).decorate(TextDecoration.BOLD)));
        return true;
    }
}
