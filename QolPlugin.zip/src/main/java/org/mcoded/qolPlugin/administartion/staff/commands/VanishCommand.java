package org.mcoded.qolPlugin.administartion.staff.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.mcoded.qolPlugin.QolPlugin;

public class VanishCommand implements CommandExecutor {
    private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
    private FileConfiguration config = plugin.config;
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!config.getBoolean("commands.staff.vanish")) {
            sender.sendMessage(Component.text("Vanish Command is turned off").color(NamedTextColor.RED));
            return false;
        }
        if (!(sender instanceof Player player)) return false;

        for (Player viewers : Bukkit.getOnlinePlayers()) {
            if (viewers.canSee(player)) {
                viewers.hidePlayer(player);
            } else {
                viewers.showPlayer(player);
            }
        }
        return true;
    }
}
