package org.mcoded.qolPlugin;

import org.bukkit.*;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.administartion.staff.commands.*;
import org.mcoded.qolPlugin.bossbar.BossbarCommand;
import org.mcoded.qolPlugin.bossbar.BossbarManager;
import org.mcoded.qolPlugin.chat.PlayerMentions;
import org.mcoded.qolPlugin.commands.CommandRemove;
import org.mcoded.qolPlugin.commands.ConfigCommand;
import org.mcoded.qolPlugin.commands.PingCommand;
import org.mcoded.qolPlugin.commands.SpawnCommand;
import org.mcoded.qolPlugin.commands.home.GUI.HomeEditGUI;
import org.mcoded.qolPlugin.chat.HomeShare;
import org.mcoded.qolPlugin.commands.home.HomeCommand;
import org.mcoded.qolPlugin.commands.home.HomeManager;
import org.mcoded.qolPlugin.commands.home.GUI.HomeSetGUI;
import org.mcoded.qolPlugin.commands.home.GUI.HomeTpGUI;
import org.mcoded.qolPlugin.commands.quality.*;
import org.mcoded.qolPlugin.commands.tpa.TpaCommand;
import org.mcoded.qolPlugin.commands.tpa.TpaManager;
import org.mcoded.qolPlugin.commands.tpa.settings.SettingsGUI;
import org.mcoded.qolPlugin.commands.tpa.settings.SettingsListener;
import org.mcoded.qolPlugin.death.DeathManager;
import org.mcoded.qolPlugin.interact.DoubleDoorListener;
import org.mcoded.qolPlugin.interact.InstaFarm;
import org.mcoded.qolPlugin.interact.SitInteract;
import org.mcoded.qolPlugin.maintanence.MaintenanceCommand;
import org.mcoded.qolPlugin.maintanence.MaintenanceWorld;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class QolPlugin extends JavaPlugin implements Listener {

    private File mcFile;
    private FileConfiguration mcConfig;
    private File mcWorldFile;
    public FileConfiguration mcWorldConfig;

    private File file;
    public File HomeFile;

    private File TempFile;
    private FileConfiguration TempConfig;

    public static NamespacedKey HomeKey;

    public FileConfiguration config;
    public FileConfiguration HomeConfig;

    private File TpaFile;
    public FileConfiguration TpaConfig;

    private File InteractFile;
    public FileConfiguration InteractFileConfig;

    private Map<UUID, HomeManager> HomeMap = new HashMap<>();
    private Map<UUID, HomeTpGUI> HomeTpMap = new HashMap<>();
    private Map<UUID, HomeSetGUI> HomeSetMap = new HashMap<>();
    private Map<UUID, HomeEditGUI> HomeEditMap = new HashMap<>();

    public DeathManager deathClass;
    public BossbarManager BossbarClass;

    private Map<UUID, SettingsGUI> TpaSettings = new HashMap<>();
    public final TpaManager tpaManager = new TpaManager();

    public World chillWorld;

    @Override
    public void onEnable() {
        // Plugin startup logic

        if (!Bukkit.getWorlds().getFirst().getName().equalsIgnoreCase("world")) {
            Bukkit.getLogger().warning("The Prime World is named " + Bukkit.getWorlds().getFirst().getName() + " it has to be named World otherwise some Function might not work!");
        }

        WorldCreator chillCreator = new WorldCreator("ChillWorld");

        chillCreator.environment(World.Environment.NORMAL);
        chillCreator.type(WorldType.FLAT);

        chillWorld = chillCreator.createWorld();

        getDataFolder().mkdirs();

        file = new File(getDataFolder(), "config.yml");
        if (!file.exists()) saveResource("config.yml", false);
        config = YamlConfiguration.loadConfiguration(file);

        File homeFolder = new File(getDataFolder(), "homes");
        homeFolder.mkdirs();

        File TpaFolder = new File(getDataFolder(), "tpa");
        TpaFolder.mkdirs();

        TpaFile = new File(TpaFolder, "tpa-player-config.yml");
        TpaConfig = YamlConfiguration.loadConfiguration(TpaFile);

        HomeFile = new File(homeFolder, "homes.yml");
        HomeConfig = YamlConfiguration.loadConfiguration(HomeFile);

        File interactFolder = new File(getDataFolder(), "interact");
        interactFolder.mkdirs();

        InteractFile = new File(interactFolder, "interact-config.yml");
        if (!InteractFile.exists()) saveResource("interact/interact-config.yml", false);
        InteractFileConfig = YamlConfiguration.loadConfiguration(InteractFile);

        File mcFolder = new File(getDataFolder(), "Maintenance");
        mcFolder.mkdirs();

        mcFile = new File(mcFolder, "maintenance.yml");
        if (!mcFile.exists()) saveResource("Maintenance/maintenance.yml", false);
        mcConfig = YamlConfiguration.loadConfiguration(mcFile);
        mcWorldFile = new File(mcFolder, "maintenance-world.yml");
        if (!mcWorldFile.exists()) saveResource("Maintenance/maintenance-world.yml", false);
        mcWorldConfig = YamlConfiguration.loadConfiguration(mcWorldFile);

        TempFile = new File(getDataFolder(), "temp.yml");
        TempConfig = YamlConfiguration.loadConfiguration(TempFile);

        try {
            HomeFile.createNewFile();
            TpaFile.createNewFile();
            TempFile.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        new MaintenanceWorld().chillWorld();

        deathClass = new DeathManager();
        BossbarClass = new BossbarManager();

        ConfigurationSection graves =
                TempConfig.getConfigurationSection("graves");

        if (graves != null) {

            for (String key : graves.getKeys(false)) {

                Location location =
                        TempConfig.getLocation("graves." + key + ".loc");

                if (location == null || location.getWorld() == null) {
                    continue;
                }

                ItemStack[] contents =
                        TempConfig.getList("graves." + key + ".items")
                                .toArray(new ItemStack[0]);

                Inventory inventory = Bukkit.createInventory(
                        null,
                        54,
                        "Grave"
                );

                inventory.setContents(contents);

                deathClass.graveMap.put(location, inventory);

                TempConfig.set("graves." + key, null);
            }
            try {
                TempConfig.save(TempFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        HomeKey = new NamespacedKey(JavaPlugin.getPlugin(QolPlugin.class), "home-mark");

        getCommand("fly").setExecutor(new FlyCommand(this.config));
        getCommand("god").setExecutor(new GodCommand(this.config));
        getCommand("vanish").setExecutor(new VanishCommand());
        getCommand("enderchest").setExecutor(new EnderchestCommand());
        getCommand("hat").setExecutor(new HatCommand());
        getCommand("craftingtable").setExecutor(new CraftingtableCommand());
        getCommand("ping").setExecutor(new PingCommand());
        getCommand("invsee").setExecutor(new InvseeCommand());
        getCommand("sit").setExecutor(new SitCommand());


        PluginCommand spawn = getCommand("spawn");
        PluginCommand config = getCommand("config");
        PluginCommand home = getCommand("home");
        PluginCommand tpa = getCommand("tpa");
        PluginCommand maintenance = getCommand("maintenance");
        PluginCommand infobar = getCommand("infobar");
        PluginCommand rename = getCommand("rename");
        PluginCommand speed = getCommand("speed");
        PluginCommand grave = getCommand("grave");

        grave.setExecutor(deathClass);
        grave.setTabCompleter(deathClass);

        speed.setExecutor(new SpeedCommand(this.config));
        speed.setTabCompleter(new SpeedCommand(this.config));

        rename.setExecutor(new RenameCommand());
        rename.setTabCompleter(new RenameCommand());

        spawn.setExecutor(new SpawnCommand(this.config));
        spawn.setTabCompleter(new SpawnCommand(this.config));

        config.setExecutor(new ConfigCommand(file, this.config, this));
        config.setTabCompleter(new ConfigCommand(file, this.config, this));

        infobar.setExecutor(new BossbarCommand());
        infobar.setTabCompleter(new BossbarCommand());

        home.setExecutor(new HomeCommand());

        tpa.setExecutor(new TpaCommand(this.config, this));
        tpa.setTabCompleter(new TpaCommand(this.config, this));

        maintenance.setExecutor(new MaintenanceCommand(mcConfig, mcFile,  this.config));
        maintenance.setTabCompleter(new MaintenanceCommand(mcConfig, mcFile,  this.config));


        PluginManager manager = Bukkit.getPluginManager();
        manager.registerEvents(new HomeManager(file, this.config, this), this);
        manager.registerEvents(new HomeSetGUI(HomeFile, HomeConfig, this), this);
        manager.registerEvents(new HomeTpGUI(HomeFile, HomeConfig, this), this);
        manager.registerEvents(new ConnectionListener(TpaConfig, TpaFile), this);
        manager.registerEvents(new SettingsListener(TpaConfig, TpaFile), this);
        manager.registerEvents(new DoubleDoorListener(InteractFileConfig), this);
        manager.registerEvents(new MaintenanceCommand(mcConfig, mcFile, this.config), this);
        manager.registerEvents(new InstaFarm(InteractFileConfig), this);
        manager.registerEvents(this, this);
        manager.registerEvents(new HomeEditGUI(HomeFile, HomeConfig), this);
        manager.registerEvents(deathClass, this);
        manager.registerEvents(new MaintenanceWorld(), this);
        manager.registerEvents(new HomeShare(), this);
        manager.registerEvents(new PlayerMentions(), this);
        manager.registerEvents(new RenameCommand(), this);
        manager.registerEvents(new SitCommand(), this);
        manager.registerEvents(new SitInteract(), this);
        manager.registerEvents(new CommandRemove(), this);

        new RecipeClass(this, "lightbulb").addLightRecipe();

        Bukkit.getScheduler().runTaskTimer(this, new FiveTickClass(TpaConfig, mcConfig, mcFile, this.config), 5L, 5L);
        getLogger().info("QoL Plugin has enabled");
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic

            getLogger().warning("QOL PLUGIN HAS DISABLED!!!!!");

        for (Map.Entry<Location, Inventory> entry : deathClass.graveMap.entrySet()) {

            Location location = entry.getKey();
            Inventory inventory = entry.getValue();

            String locString =
                    location.getWorld().getName()
                            + "_" + location.getBlockX()
                            + "_" + location.getBlockY()
                            + "_" + location.getBlockZ();

            TempConfig.set(
                    "graves." + locString + ".loc",
                    location
            );

            TempConfig.set(
                    "graves." + locString + ".items",
                    inventory.getContents()
            );

            TempConfig.set(
                    "graves." + locString + ".title",
                    inventory.getType().name()
            );
        }

        try {
            TempConfig.save(TempFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public HomeManager getHomeManager(Player player) {
        return HomeMap.computeIfAbsent(
                player.getUniqueId(),
                uuid -> new HomeManager(HomeFile, HomeConfig, this)
        );
    }
    public HomeTpGUI getHomeTp(Player player) {
        return HomeTpMap.computeIfAbsent(
                player.getUniqueId(),
                uuid -> new HomeTpGUI(HomeFile, HomeConfig, this)
        );
    }
    public HomeSetGUI getHomeSet(Player player) {
        return HomeSetMap.computeIfAbsent(
                player.getUniqueId(),
                uuid -> new HomeSetGUI(HomeFile, HomeConfig, this)
        );
    }

    public SettingsGUI getTpaSetting(Player player) {
        return TpaSettings.computeIfAbsent(
                player.getUniqueId(),
                uuid -> new SettingsGUI(TpaConfig)
        );
    }

    public HomeEditGUI getHomeEdit(Player player) {
        return HomeEditMap.computeIfAbsent(
                player.getUniqueId(),
                uuid -> new HomeEditGUI(HomeFile, HomeConfig)
        );
    }
}
