package org.mcoded.qolPlugin.commands.tpa.settings;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public enum GuiItems {

    gui;

    public ItemStack closeItem() {
            ItemStack closeItem = new ItemStack(Material.BARRIER);
            ItemMeta closeItemMeta = closeItem.getItemMeta();

            closeItemMeta.setEnchantmentGlintOverride(true);
            closeItemMeta.itemName(Component.text("Close").decorate(TextDecoration.BOLD).color(NamedTextColor.RED));
            closeItem.setItemMeta(closeItemMeta);

            return closeItem;
    }
        public ItemStack BackItem() {
            ItemStack closeItem = new ItemStack(Material.BARRIER);
            ItemMeta closeItemMeta = closeItem.getItemMeta();

            closeItemMeta.setEnchantmentGlintOverride(true);
            closeItemMeta.itemName(Component.text("Back").decorate(TextDecoration.BOLD).color(NamedTextColor.RED));
            closeItem.setItemMeta(closeItemMeta);

            return closeItem;
    }
        public ItemStack frameItem(Material GlassPane) {
            ItemStack frameItem = new ItemStack(GlassPane);
            ItemMeta frameItemMeta = frameItem.getItemMeta();

            frameItemMeta.customName(Component.empty());

            frameItem.setItemMeta(frameItemMeta);

            return frameItem;
    }
        public int[] ChestFrameSlots() {

            return new int[]{
                    1, 2, 3, 4, 5, 6, 7, 8,
                    9,                  17,
                    18,                 26,
                    27,                 35,
                    36, 37, 38, 39, 40, 41, 42, 43, 44,
            };
    }
    public ItemStack TpAuto(FileConfiguration config, Player player) {
        ItemStack item;
        ItemMeta meta;

        if (config.getBoolean(player.getUniqueId() + ".tpAuto")) {
            item = new ItemStack(Material.GREEN_CONCRETE);
            meta = item.getItemMeta();

            meta.setEnchantmentGlintOverride(true);
            meta.itemName(Component.text("Tp Auto: Enabled").color(NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false).decorate(TextDecoration.BOLD));


        } else {
            item = new ItemStack(Material.RED_CONCRETE);
            meta = item.getItemMeta();

            meta.itemName(Component.text("Tp Auto: Disabled").color(NamedTextColor.RED).decoration(TextDecoration.ITALIC, false).decorate(TextDecoration.BOLD));

        }

        meta.lore(List.of(
                Component.empty(),
                Component.text("Click to toogle").color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.empty()
        ));

        item.setItemMeta(meta);

        return item;
    }

    public ItemStack Tpa(FileConfiguration config, Player player) {
        ItemStack item;
        ItemMeta meta;

        if (config.getBoolean(player.getUniqueId() + ".tpa")) {
            item = new ItemStack(Material.ENDER_PEARL);
            meta = item.getItemMeta();

            meta.setEnchantmentGlintOverride(true);
            meta.itemName(Component.text("Tpa: Enabled").color(NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false).decorate(TextDecoration.BOLD));


        } else {
            item = new ItemStack(Material.ENDER_PEARL);
            meta = item.getItemMeta();

            meta.itemName(Component.text("Tpa: Disabled").color(NamedTextColor.RED).decoration(TextDecoration.ITALIC, false).decorate(TextDecoration.BOLD));

        }

        meta.lore(List.of(
                Component.empty(),
                Component.text("Click to toogle").color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                Component.empty()
        ));

        item.setItemMeta(meta);

        return item;
    }
}
