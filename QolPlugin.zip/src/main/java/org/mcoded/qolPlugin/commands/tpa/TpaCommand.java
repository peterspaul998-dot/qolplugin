package org.mcoded.qolPlugin.commands.tpa;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mcoded.qolPlugin.QolPlugin;

import java.util.ArrayList;
import java.util.List;

public class TpaCommand implements CommandExecutor, TabCompleter {

    private final FileConfiguration config;
    private final QolPlugin e;

    public TpaCommand(FileConfiguration config, QolPlugin q) {
        e = q;
        this.config = config;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!(sender instanceof Player player)) return false;

        if (config.get("commands.tpa").equals(false)) {
            player.sendMessage(Component.text("Tpa Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        TpaManager manager = e.tpaManager;

            switch (args[0]) {

                case "request" -> {
                    Player target = Bukkit.getPlayer(args[1]);

                    if (target == null) {
                        player.sendMessage(Component.text("Player is not online").color(NamedTextColor.RED));
                        return false;
                    }

                    manager.request(player, target, e.TpaConfig);

                }
                case "accept" -> {
                    Player target = Bukkit.getPlayer(args[1]);

                    if (target == null) {
                        player.sendMessage(Component.text("Player is not online").color(NamedTextColor.RED));
                        return false;
                    }

                    manager.accept(player, target);

                }
                case "get" -> {
                    for (Object ob : manager.getrequest(player)) {
                        player.sendMessage(ob.toString());
                    }
                }
                case "settings" -> {
                    e.getTpaSetting(player).SettingsOpen(player);
                }
            }
            return true;
        }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        Player player = (Player) sender;

        if (args.length == 1) return List.of("accept", "request", "get", "settings".toLowerCase()).stream().filter(s -> s.startsWith(args[0])).toList();

        List<String> playerlist = new ArrayList<>(List.of());

        for (Player players : Bukkit.getOnlinePlayers()) {
            if (players != player) playerlist.add(players.getName());
        }

        if (args.length == 2 && args[0].equals("accept")) return e.tpaManager.getrequest(player);
        if (args.length == 2 && args[0].equals("request")) return playerlist;

        return List.of();
    }
}
