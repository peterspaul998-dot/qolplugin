package org.mcoded.qolPlugin.commands.home;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mcoded.qolPlugin.QolPlugin;
import org.mcoded.qolPlugin.commands.home.GUI.HomeEditGUI;
import org.mcoded.qolPlugin.commands.home.GUI.HomeSetGUI;
import org.mcoded.qolPlugin.commands.home.GUI.HomeTpGUI;

import java.util.List;

public class HomeCommand implements CommandExecutor, TabCompleter {

    private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
    private final FileConfiguration config = plugin.config;
    private final FileConfiguration HomeConfig = plugin.HomeConfig;


    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!(sender instanceof Player player)) return false;

        if (!config.getBoolean("commands.home")) {
            player.sendMessage(Component.text("Home Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        HomeTpGUI Tpmanager = plugin.getHomeTp(player);
        HomeSetGUI Setmanager = plugin.getHomeSet(player);
        HomeManager manager = plugin.getHomeManager(player);

        if (args.length == 0) {
            manager.HomeGUI(player);
            return true;
        }

        switch (args[0]) {
            case "tp" -> {
                if (args.length == 1) {
                    Tpmanager.HomeTp(player);
                    return true;
                }
                int home;
                int max = config.getInt("max-homes");
                try {
                   home = Integer.parseInt(args[1]);
                } catch (NumberFormatException e) {
                    player.sendMessage(Component.text("Please enter a vaild Home Number").color(NamedTextColor.RED));
                    return false;
                }

                if (home > max) {
                    player.sendMessage(Component.text("Home is out of range. The max Home is " + max).color(NamedTextColor.RED));
                    return false;
                }

                if (HomeConfig.get(player.getUniqueId() + ".home" + home) == null) {
                    player.sendMessage(Component.text("You have no Home ").color(NamedTextColor.RED)
                            .append(Component.text(home).decorate(TextDecoration.BOLD)));
                    return false;
                }


                plugin.getHomeTp(player).TeleportPlayer(player, home);
                return true;
            }
            case "set" -> {
               if (args.length == 1) {
                   Setmanager.openfreshinv(player);
                   return true;
               }
                int home;
                int max = config.getInt("max-homes");
                try {
                    home = Integer.parseInt(args[1]);
                } catch (NumberFormatException e) {
                    player.sendMessage(Component.text("Please enter a vaild Home Number").color(NamedTextColor.RED));
                    return false;
                }
                if (home > max) {
                    player.sendMessage(Component.text("Home is out of range. The max Home is " + max).color(NamedTextColor.RED));
                    return false;
                }

                plugin.getHomeEdit(player).OpenGUI(player, home);
                return true;
            }
        }


        player.sendMessage("Usage: /home (<set/tp>)");
        return false;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {

        if (args.length == 1) return List.of("set", "tp".toLowerCase()).stream().filter(s -> s.startsWith(args[0])).toList();
        if (args.length == 2) return List.of("<number>");
        return List.of();
    }
}
