package org.mcoded.qolPlugin.maintanence;


import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.QolPlugin;

public class MaintenanceWorld implements Listener {

    private FileConfiguration Worldconfig = JavaPlugin.getPlugin(QolPlugin.class).mcWorldConfig;
    private World world = JavaPlugin.getPlugin(QolPlugin.class).chillWorld;
    public void chillWorld() {
        world.getWorldBorder().setCenter(Worldconfig.getInt("worldborder-center.x"), Worldconfig.getInt("worldborder-center.z"));
        world.getWorldBorder().changeSize((Worldconfig.getInt("worldborder", 50)), 1);
        world.setSpawnLocation(Worldconfig.getInt("spawn.x", 0), Worldconfig.getInt("spawn.y", -60), Worldconfig.getInt("spawn.z", 0));
        world.setDifficulty(difficulty());
        if (!daycycle()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "execute in minecraft:chillworld run gamerule advance_time false");
        if (!weathercycle()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "execute in minecraft:chillworld run gamerule advance_weather false");
    }

    // checkt ob deine mutter die weather cycle einstellung angemacht hat
    public Boolean weathercycle() { return Worldconfig.getBoolean("weather-cycle"); }

    // checkt ob deine mutter die day cycle einstellung angemacht hat
    public Boolean daycycle() { return Worldconfig.getBoolean("day-cycle"); }

    // checkt ob deine mutter die mob spawning einstellung angemacht hat
    public Boolean mobspawning() { return Worldconfig.getBoolean("allow-mob-spawn"); }

    // Gibt die Difficulty zurück die in der WorldConfig eingestellt wurde
    public Difficulty difficulty() {
        switch (Worldconfig.getString("difficulty", "peaceful")) {
            case "peaceful" ->  {
                return Difficulty.PEACEFUL;
            }
            case "easy" ->  {
                return Difficulty.EASY;
            }
            case "normal" ->  {
                return Difficulty.NORMAL;
            }
            case "hard" -> {
                return Difficulty.HARD;
            }
        }
        Bukkit.getLogger().warning("No Difficulty configured in Maintenance World using Peaceful as default");
        return  Difficulty.PEACEFUL;
    }

    @EventHandler
    public void onEntitySpawn(EntitySpawnEvent e) {
        if (!e.getLocation().getWorld().equals(world)) return;
        if (mobspawning()) return;

        e.setCancelled(true);
    }
}
