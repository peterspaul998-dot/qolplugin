package org.mcoded.qolPlugin.commands.tpa.settings;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.QolPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class SettingsListener implements Listener {

    private FileConfiguration config;
    private File file;

    public SettingsListener(FileConfiguration config, File file) {
        this.config = config;
        this.file = file;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof SettingsGUI)) return;

        Player player = (Player) e.getWhoClicked();
        UUID uuid = player.getUniqueId();

        ItemStack item = e.getCurrentItem();

        if (item == null) return;

        e.setCancelled(true);

        if (item.isSimilar(GuiItems.gui.TpAuto(config, player))) {
            if (config.getBoolean(uuid + ".tpAuto")) config.set(uuid + ".tpAuto", false);
            else if (!config.getBoolean(uuid + ".tpAuto")) config.set(uuid + ".tpAuto", true);
            JavaPlugin.getPlugin(QolPlugin.class).getTpaSetting(player).SettingsOpen(player);
        }
        if (item.isSimilar(GuiItems.gui.Tpa(config, player))) {
            if (config.getBoolean(uuid + ".tpa")) config.set(uuid + ".tpa", false);
            else if (!config.getBoolean(uuid + ".tpa")) config.set(uuid + ".tpa",true);
            JavaPlugin.getPlugin(QolPlugin.class).getTpaSetting(player).SettingsOpen(player);
        }

        if (item.isSimilar(GuiItems.gui.closeItem())) player.closeInventory();

        try {
            config.save(file);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

}
