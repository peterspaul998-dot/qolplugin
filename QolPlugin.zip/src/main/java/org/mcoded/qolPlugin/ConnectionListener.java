package org.mcoded.qolPlugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class ConnectionListener implements Listener {

    private final QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
    private final FileConfiguration TpaConfig;
    private final File TpaFile;
    private final FileConfiguration config = plugin.config;

    public ConnectionListener(FileConfiguration tpaConfig, File tpaFile) {
        TpaConfig = tpaConfig;
        TpaFile = tpaFile;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();
        UUID uuid = player.getUniqueId();

        if (!Bukkit.getWorlds().getFirst().getName().equals("world")) {
            player.sendMessage(Component.text(
                    "The Prime World is named "
                            + Bukkit.getWorlds().getFirst().getName()
                            + " it has to be named World otherwise some Function might not work!").color(NamedTextColor.RED))
                    ;
        }




        if (TpaConfig.get(uuid.toString()) == null) {
            TpaConfig.set(uuid + ".tpAuto", false);
            TpaConfig.set(uuid + ".name", player.getName());
            TpaConfig.set(uuid + ".tpa", true);
        }
        try {
            TpaConfig.save(TpaFile);
        } catch (IOException ex) {
            ex.printStackTrace();
        }



        String formatted = config.getString(
                "join-message",
                "&e{player} joined the game"
        )
                .replace("{player}", player.getName())
                .replace("{x}", String.valueOf(player.getLocation().getBlockX()))
                .replace("{y}", String.valueOf(player.getLocation().getBlockY()))
                .replace("{z}", String.valueOf(player.getLocation().getBlockZ()))
                ;
        Component message = LegacyComponentSerializer.legacyAmpersand().deserialize(formatted);

        e.joinMessage(message);
    }

    @EventHandler
    public void onLeave(PlayerQuitEvent e) {
        Player player = e.getPlayer();

        String formatted = config.getString(
                        "leave-message",
                        "&e{player} left the game"
                )
                .replace("{player}", player.getName())
                .replace("{x}", String.valueOf(player.getLocation().getBlockX()))
                .replace("{y}", String.valueOf(player.getLocation().getBlockY()))
                .replace("{z}", String.valueOf(player.getLocation().getBlockZ()))
                ;
        Component message = LegacyComponentSerializer.legacyAmpersand().deserialize(formatted);

        e.quitMessage(message);
    }
}
