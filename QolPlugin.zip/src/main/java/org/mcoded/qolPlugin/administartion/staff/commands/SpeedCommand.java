package org.mcoded.qolPlugin.administartion.staff.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class SpeedCommand implements TabExecutor {
    private final FileConfiguration config;

    public SpeedCommand(FileConfiguration config) {
        this.config = config;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!config.getBoolean("commands.staff.speed")) {
            sender.sendMessage(Component.text("Speed Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (!(sender instanceof Player player)) return false;

        if (player.hasPotionEffect(PotionEffectType.SPEED)) {
            player.removePotionEffect(PotionEffectType.SPEED);
            player.sendMessage(Component.text("You dont have Speed anymore").color(NamedTextColor.RED));
        } else {
            if (args.length != 1) return false;
            int speed;
            try {
                speed = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                player.sendMessage(Component.text("That is not a valid number!").color(NamedTextColor.RED));
                return false;
            }

            if (speed > 255) speed = 255;

            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.SPEED,
                    -1,
                    speed,
                    false,
                    false

            ));
        }

        return true;

    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
       if (args.length == 1) return List.of("<1-255>");
       return null;
    }
}
