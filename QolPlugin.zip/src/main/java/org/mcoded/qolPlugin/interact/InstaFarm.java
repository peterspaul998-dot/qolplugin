package org.mcoded.qolPlugin.interact;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
public class InstaFarm implements Listener {

    private final FileConfiguration config;

    public InstaFarm(FileConfiguration config) {
        this.config = config;
    }

    @EventHandler
    public void onBlockInteract(PlayerInteractEvent e) {

        if (!config.getBoolean("insta-farm")) return;

        if (!e.getAction().isRightClick()) return;

        if (e.getClickedBlock() == null) return;

        Block block = e.getClickedBlock();

        if (!(block.getBlockData() instanceof Ageable age)) return;

        if (age.getAge() != age.getMaximumAge()) return;

        Material SetBlock = block.getType();

        block.breakNaturally();
        block.setType(SetBlock);
   }
}
