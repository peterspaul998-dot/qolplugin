package org.mcoded.qolPlugin.bossbar;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.QolPlugin;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;


public class BossbarManager{
        private BossBar bossBar =  BossBar.bossBar(Component.text("test"), 1.0f, BossBar.Color.GREEN, BossBar.Overlay.PROGRESS);
        private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
        private FileConfiguration config = plugin.config;

        public void showBossbar(Player player) {
            player.showBossBar(bossBar);
        }

        public void hideBossBar(Player player) { player.hideBossBar(bossBar); }

        public void UpdateBossbar() {
            String formatted = String.format(
                    config.getString("bossbar-title", "{realtime}          &a&l{gametime}&r    &1&l{players}&r &1Online Players")
                            .replace("{realtime}",GetRealTime())
                            .replace("{gametime}",TimeCalc(Bukkit.getWorld("world").getTime()))
                            .replace("{players}", String.valueOf(Bukkit.getOnlinePlayers().size()))
            );

            Component title = LegacyComponentSerializer.legacyAmpersand().deserialize(formatted);
            bossBar.name(title);


            bossBar.progress(ProcentCalc(Bukkit.getWorld("world").getTime()));
        }


        public String TimeCalc(long ticks) {
            double time = (double) ticks;

            int timeint = (int) time / 1000 + 6;

            if (timeint >= 24) {
                timeint -= 24;
            }

            double s = time % 1000 * 60 / 1000;

            int timeSint = (int) s;

            String formatH = String.format("%02d", timeint);
            String formatS = String.format("%02d", timeSint);

            return formatH + ":" + formatS;
        }

        public float ProcentCalc(long temp) {

            float time = temp;

            float temp1 = time;
            float temp2 = time;

            if (temp1 >= 18001f) {
                time -= 18000f;
            }
            if (temp2 <= 18000) time = time + 6000f;

            return time / 24000f;


        }

        public String GetRealTime() {

            LocalTime time = LocalTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");

            return formatter.format(time);

        }

}
