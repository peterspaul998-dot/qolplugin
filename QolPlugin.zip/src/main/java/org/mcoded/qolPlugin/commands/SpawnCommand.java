package org.mcoded.qolPlugin.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class SpawnCommand implements CommandExecutor, TabCompleter {

    private final FileConfiguration config;

    public SpawnCommand(FileConfiguration config) {
        this.config = config;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!(sender instanceof Player player)) return false;

        if (config.get("commands.spawn").equals(false)) {
            player.sendMessage(Component.text("Spawn Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (args.length == 0) {

            if (player.getRespawnLocation() == null) {
                player.sendMessage(Component.text("You have no Respawnpoint").color(NamedTextColor.RED));
                return false;
            }

            player.teleport(player.getRespawnLocation());
            return true;
        }
        switch (args[0]) {

            case "set" -> {
                player.setRespawnLocation(player.getLocation(), true);
                player.sendMessage(Component.text("Respawn point has been set to: " + player.getLocation().getBlockX() + " " + player.getLocation().getBlockY() + " " + player.getLocation().getBlockZ()).color(NamedTextColor.BLUE));
                return true;
            }
            case "reset" -> {
                if (player.getRespawnLocation() == null) return false;
                player.setRespawnLocation(null, true);
                player.sendMessage(Component.text("Your Respawn Point has been removed").color(NamedTextColor.RED));
            }
            case "tp" -> {
                if (player.getRespawnLocation() == null) {
                    player.sendMessage(Component.text("You have no Respawnpoint").color(NamedTextColor.RED));
                    return false;
                }

                player.teleport(player.getRespawnLocation());
                return true;
            }
        }

        return false;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {

        if (args.length == 1) {
            return List.of("set", "reset", "tp").stream().filter(s -> s.startsWith(args[0].toLowerCase())).toList();
        }

        return List.of();
    }
}
