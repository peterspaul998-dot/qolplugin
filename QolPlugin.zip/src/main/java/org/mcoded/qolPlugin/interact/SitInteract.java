package org.mcoded.qolPlugin.interact;

import org.bukkit.Bukkit;
import org.bukkit.block.data.type.Stairs;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;
import org.mcoded.qolPlugin.QolPlugin;
import org.mcoded.qolPlugin.commands.quality.SitCommand;

public class SitInteract implements Listener {
    private final FileConfiguration config = JavaPlugin.getPlugin(QolPlugin.class).InteractFileConfig;

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        if (!config.getBoolean("sit")) return;

        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!(e.getClickedBlock().getBlockData() instanceof Stairs data)) return;
        Player player = e.getPlayer();

        Vector vec =  data.getFacing().getOppositeFace().getDirection();
                new SitCommand().PlayerSit(player, e.getClickedBlock()
                        .getLocation()
                        .toCenterLocation()
                        .subtract(0,1,0).setDirection(vec));

    }
}
