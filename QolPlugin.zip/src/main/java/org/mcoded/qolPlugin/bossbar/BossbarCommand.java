package org.mcoded.qolPlugin.bossbar;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mcoded.qolPlugin.QolPlugin;

import java.util.List;

public class BossbarCommand implements TabExecutor {

    private BossbarManager bossmanager = JavaPlugin.getPlugin(QolPlugin.class).BossbarClass;
    private FileConfiguration config = JavaPlugin.getPlugin(QolPlugin.class).config;

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (!(sender instanceof Player player)) return false;

        if (!config.getBoolean("commands.infobar")) {
            player.sendMessage(Component.text("Infobar Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (args.length != 1) {
            player.sendMessage(Component.text("Usage: /infobar <on/off>").color(NamedTextColor.RED));
            return false;
        }
        switch(args[0]) {
            case "on" -> {
                bossmanager.showBossbar(player);
                return true;
            }
            case "off" -> {
                bossmanager.hideBossBar(player);
                return true;
            }
        }
        player.sendMessage(Component.text("Usage: /infobar <on/off>").color(NamedTextColor.RED));
        return false;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (args.length == 1) return List.of("on", "off".toLowerCase()).stream().filter(s -> s.startsWith(args[0])).toList();
        return List.of();
    }
}
