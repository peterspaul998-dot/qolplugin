package org.mcoded.qolPlugin.commands.home.GUI;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.NotNull;
import org.mcoded.qolPlugin.QolPlugin;
import org.mcoded.qolPlugin.commands.home.HomeManager;

import java.io.File;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class HomeTpGUI implements InventoryHolder, Listener {

    private Inventory inv;
    private final FileConfiguration HomeConfig;
    private final QolPlugin plugin;
    private final FileConfiguration config;
    private Map<UUID, Integer> canTeleport = new HashMap<>();
    private BukkitTask timer;
    private AtomicInteger cooldown;

    public HomeTpGUI(File file, FileConfiguration config, QolPlugin plugin) {
        this.HomeConfig = config;
        this.plugin = plugin;
        inv = Bukkit.createInventory(this, 9 * 6, Component.text("Your Homes"));
        this.config = plugin.config;
    }
    public void HomeTp(Player player) {
        getTpInv(player, 0);
    }
    public void openTpInvNext(Player player, int start) {
        getTpInv(player, start);
    }
    public void openTpInvPrev(Player player, int start) {
        start = start - 11;
        if (start < 0) return;
        getTpInv(player, start);
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inv;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e ) {
        if (e.getClickedInventory() == null) return;
        if (!(e.getClickedInventory().getHolder() instanceof HomeTpGUI)) return;
        Inventory inventory = e.getClickedInventory();

        Player player = (Player) e.getWhoClicked();

        e.setCancelled(true);

        ItemStack item = e.getCurrentItem();

        if (item == null) return;

        if (item.isSimilar(HomeGUI.HOME_GUI.BackItem())) {
            HomeManager manager = plugin.getHomeManager(player);
            manager.HomeGUI(player);
        }

        String key = item.getItemMeta().getPersistentDataContainer().get(QolPlugin.HomeKey, PersistentDataType.STRING);

        if (key == null) key = "ficken";

        if (key.equalsIgnoreCase("home")) {
            int home = Integer.parseInt(item.getItemMeta().getItemName());

            plugin.getHomeTp(player).TeleportPlayer(player, home);
            player.closeInventory();
        }
        if (item.isSimilar(HomeGUI.HOME_GUI.nextSite())) {
            int start = 0;
            for (int i = 33; i > 20; i--) {
                if (inventory.getItem(i) == null) {
                    continue;
                }
                start = Integer.parseInt(PlainTextComponentSerializer.plainText().serialize(inventory.getItem(i).getItemMeta().itemName()));
                break;
            }
            openTpInvNext(player, start);
        }
        if (item.isSimilar(HomeGUI.HOME_GUI.prevSite())) {

            // Gets the first home and executes the openSetInvPrev function
            openTpInvPrev(player, Integer.parseInt(PlainTextComponentSerializer.plainText().serialize(inventory.getItem(20)
                    .getItemMeta()
                    .itemName())));
        }
    }

    public void getTpInv(Player player, int start_homes) {
        int homes = plugin.config.getInt("max-homes");
        if (start_homes + 1 > homes) return;
        inv.setContents(new ItemStack[0]);
        int max = 10;

        inv.setItem(0, HomeGUI.HOME_GUI.BackItem());

        for (int slot : HomeGUI.HOME_GUI.DoubleChestFrameSlots())
            inv.setItem(slot, HomeGUI.HOME_GUI.frameItem(Material.LIME_STAINED_GLASS_PANE));
        inv.setItem(53, HomeGUI.HOME_GUI.nextSite());
        inv.setItem(45, HomeGUI.HOME_GUI.prevSite());

        for (int i = 0; i < max; i++) {
            int index = i + 20;

            if (index >= 25) index = index + 4;

            // Man muss das start home -1 machen weil es auch beim 1. mal +1 rechnet
            start_homes = start_homes + 1;

            if (start_homes > homes) break;

            if (HomeConfig.get(player.getUniqueId() + ".home" + start_homes) == null) inv.setItem(index, HomeGUI.HOME_GUI.emptyHome(start_homes));
            else inv.setItem(index, HomeConfig.getItemStack(player.getUniqueId() + ".home" + start_homes + ".icon"));
        }
        player.openInventory(inv);
    }

    public void TeleportPlayer(Player player, int Home) {
        if (!config.getBoolean("home.teleport-cooldown.enabled")) {
            player.teleport(HomeConfig.getLocation(player.getUniqueId() + ".home" + Home + ".loc"));
            player.sendMessage(Component.text("You have been teleported to your Home ").color(NamedTextColor.GREEN)
                    .append(Component.text(Home).decorate(TextDecoration.BOLD)));
            return;
        }
        if (canTeleport(player)) {
            player.teleport(HomeConfig.getLocation(player.getUniqueId() + ".home" + Home + ".loc"));
            player.sendMessage(Component.text("You have been teleported to your Home ").color(NamedTextColor.GREEN)
                    .append(Component.text(Home).decorate(TextDecoration.BOLD)));
            startTeleportCooldown(player);
        }
        else {
            player.sendMessage(Component.text("Your Still on Cooldown: " + canTeleport.get(player.getUniqueId()) + "s").color(NamedTextColor.RED));
        }

    }
    private void startTeleportCooldown(Player player) {
        cooldown = new AtomicInteger(config.getInt("home.teleport-cooldown.cooldown", 10));

        canTeleport.put(player.getUniqueId(), cooldown.get());
        player.sendActionBar(
                Component.text("Home Tp Cooldown: " + canTeleport.get(player.getUniqueId()) + "s").color(NamedTextColor.RED));


        timer = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            cooldown.set(cooldown.get() - 1);
            canTeleport.put(player.getUniqueId(), cooldown.get());
            player.sendActionBar(
                    Component.text("Home Tp Cooldown: " + canTeleport.get(player.getUniqueId()) + "s").color(NamedTextColor.RED));
        }, 20L, 20L);

    }
    private boolean canTeleport(Player player) {
        return canTeleport.get(player.getUniqueId()) == null;
    }
    public void stopTimer(Player player) {
        if (canTeleport.get(player.getUniqueId()) == null) return;
        if (cooldown.get() <= 0) {
            Bukkit.getScheduler().cancelTask(timer.getTaskId());
            canTeleport.remove(player.getUniqueId());
        }
    }
}
