package org.mcoded.qolPlugin.commands.home;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Transformation;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3f;
import org.mcoded.qolPlugin.QolPlugin;
import org.mcoded.qolPlugin.commands.home.GUI.HomeGUI;
import org.mcoded.qolPlugin.commands.home.GUI.HomeSetGUI;
import org.mcoded.qolPlugin.commands.home.GUI.HomeTpGUI;

import java.io.File;
import java.io.IOException;

public class HomeManager implements InventoryHolder, Listener {

    private final QolPlugin plugin;
    private Inventory inv;
    private final File file;
    private final FileConfiguration config;
    private final FileConfiguration HomeConfig;

    public HomeManager(File file, FileConfiguration config, QolPlugin plugin) {
        this.file = file;
        this.config = config;
        this.plugin = plugin;
        HomeConfig = plugin.HomeConfig;
    }

    public void HomeGUI(Player player) {
        inv = Bukkit.createInventory(this, 9 * 5, Component.text(player.getName() + "´s Homes"));

        inv.setItem(0, HomeGUI.HOME_GUI.closeItem());

        for (int slot : HomeGUI.HOME_GUI.ChestFrameSlots()) {
            inv.setItem(slot, HomeGUI.HOME_GUI.frameItem(Material.LIME_STAINED_GLASS_PANE));
        }

        inv.setItem(21, HomeGUI.HOME_GUI.HomeTp());

        inv.setItem(23, HomeGUI.HOME_GUI.HomeSet());

        player.openInventory(inv);

    }

    @Override
    public @NotNull Inventory getInventory() {
        return inv;
    }
    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof HomeManager)) return;

        Player player = (Player) e.getWhoClicked();
        HomeSetGUI SetManager = plugin.getHomeSet(player);

        ItemStack item = e.getCurrentItem();

        e.setCancelled(true);

        if (item == null) return;

        if (item.isSimilar(HomeGUI.HOME_GUI.closeItem())) player.closeInventory();

        if (item.isSimilar(HomeGUI.HOME_GUI.HomeSet())) {
            SetManager.openfreshinv(player);
        }
        if (item.isSimilar(HomeGUI.HOME_GUI.HomeTp())) {
            HomeTpGUI manager = plugin.getHomeTp(player);
            manager.HomeTp(player);
        }
    }


}
