package org.mcoded.qolPlugin.commands.home.GUI;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.mcoded.qolPlugin.QolPlugin;
import org.mcoded.qolPlugin.commands.home.HomeManager;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class HomeSetGUI implements InventoryHolder, Listener {

    private Inventory inv;
    private final File file;
    private final FileConfiguration config;
    private final QolPlugin plugin;

    public HomeSetGUI(File file, FileConfiguration config, QolPlugin plugin) {
        this.file = file;
        this.config = config;
        this.plugin = plugin;
        inv = Bukkit.createInventory(this, 9 * 6, Component.text("Your Set Home"));
    }

    @Override
    public @NotNull Inventory getInventory() {
        return inv;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getClickedInventory() == null) return;
        if (!(e.getClickedInventory().getHolder() instanceof HomeSetGUI)) return;


        Inventory inventory = e.getClickedInventory();

        e.setCancelled(true);

        Player player = (Player) e.getWhoClicked();

        ItemStack item = e.getCurrentItem();

        if (item == null) return;

        if (item.isSimilar(HomeGUI.HOME_GUI.BackItem())) {
            HomeManager manager = plugin.getHomeManager(player);

            manager.HomeGUI(player);
        }

        String key = item.getItemMeta().getPersistentDataContainer().get(QolPlugin.HomeKey, PersistentDataType.STRING);

        if (key == null) key = "ficken";

        if (key.equalsIgnoreCase("home")) {
            int count = Integer.parseInt(item.getItemMeta().getItemName());
            plugin.getHomeEdit(player).OpenGUI(player, count);
        }

        if (item.isSimilar(HomeGUI.HOME_GUI.nextSite())) {
            int start = 0;
            for (int i = 33; i > 20; i--) {
                if (inventory.getItem(i) == null) {
                    continue;
                }
                start = Integer.parseInt(PlainTextComponentSerializer.plainText().serialize(inventory.getItem(i).getItemMeta().itemName()));
                break;
            }
            openSetInv(player, start);
        }
        if (item.isSimilar(HomeGUI.HOME_GUI.prevSite())) {

            // Gets the first home and executes the openSetInvPrev function
            openSetInvPrev(player, Integer.parseInt(PlainTextComponentSerializer.plainText().serialize(inventory.getItem(20)
                    .getItemMeta()
                    .itemName())));
        }
    }

    public void getSetInv(Player player, int start_homes) {
        int homes = plugin.config.getInt("max-homes");
        if (start_homes + 1 > homes) return;
        inv.setContents(new ItemStack[0]);
        int max = 10;

        inv.setItem(0, HomeGUI.HOME_GUI.BackItem());

        for (int slot : HomeGUI.HOME_GUI.DoubleChestFrameSlots())
            inv.setItem(slot, HomeGUI.HOME_GUI.frameItem(Material.LIME_STAINED_GLASS_PANE));
        inv.setItem(53, HomeGUI.HOME_GUI.nextSite());
        inv.setItem(45, HomeGUI.HOME_GUI.prevSite());

        for (int i = 0; i < max; i++) {
            int index = i + 20;

            if (index >= 25) index = index + 4;

            // Man muss das start home -1 machen weil es auch beim 1. mal +1 rechnet
            start_homes = start_homes + 1;

            if (start_homes > homes) break;

            if (config.get(player.getUniqueId() + ".home" + start_homes) == null) {
                inv.setItem(index, HomeGUI.HOME_GUI.Homes(start_homes));
            }
            else {
                inv.setItem(index, config.getItemStack(player.getUniqueId() + ".home" + start_homes + ".icon"));
            }
        }
        player.openInventory(inv);
    }
    public void openSetInv(Player player, int start) {

        getSetInv(player, start);
    }
    public void openfreshinv(Player player) {
        getSetInv(player, 0);
    }
    public void openSetInvPrev(Player player, int start) {
        start = start - 11;
        if (start < 0) return;
        getSetInv(player, start);
    }
}
