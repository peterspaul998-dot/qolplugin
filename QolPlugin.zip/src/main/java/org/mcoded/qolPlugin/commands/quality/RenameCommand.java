package org.mcoded.qolPlugin.commands.quality;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mcoded.qolPlugin.QolPlugin;

import java.util.List;


public class RenameCommand implements TabExecutor, Listener {

    private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
    private FileConfiguration config = plugin.config;

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {

        if (!config.getBoolean("commands.quality.rename")) {
            sender.sendMessage(Component.text("Rename Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (!(sender instanceof Player player)) return false;

        Component usage = Component.text("Usage: /rename (reset)").color(NamedTextColor.RED);

        if (args.length == 0) {
            player.sendMessage(Component.text("Write the Name for your Item in the Chat. You can also use Mini Message Format")
                    .color(NamedTextColor.GOLD));
            player.addScoreboardTag("qolplugin.rename");
            return true;
        }
        if (args.length != 1) {
            player.sendMessage(usage);
            return false;
        }

        if (!args[0].equalsIgnoreCase("reset")) {
            player.sendMessage(usage);
            return false;
        }
        player.removeScoreboardTag("qolplugin.rename");
        player.sendMessage(Component.text("Cancelled").color(NamedTextColor.RED));
        return true;
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        if (!e.getPlayer().getScoreboardTags().contains("qolplugin.rename")) return;
        Player player = e.getPlayer();

        Component formatted = MiniMessage.miniMessage().deserialize(PlainTextComponentSerializer.plainText().serialize(e.message()));


        e.setCancelled(true);
        ItemMeta meta = player.getInventory().getItemInMainHand().getItemMeta();

        if (meta == null) {
            player.sendMessage(Component.text("You need an Item in your Mainhand").color(NamedTextColor.RED));
            return;
        }
        meta.customName(formatted);

        player.getInventory().getItemInMainHand().setItemMeta(meta);
        player.removeScoreboardTag("qolplugin.rename");
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {
        if (args.length == 1) return List.of("reset");
        return List.of();
    }
}
