package org.mcoded.qolPlugin.administartion.staff.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class FlyCommand implements CommandExecutor {
    private final FileConfiguration config;

    public FlyCommand(FileConfiguration config) {
        this.config = config;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {

        if (!config.getBoolean("commands.staff.fly")) {
            sender.sendMessage(Component.text("Fly Command is turned off").color(NamedTextColor.RED));
            return false;
        }

        if (!(sender instanceof Player player)) return false;

        if (player.getAllowFlight()) {
            player.setAllowFlight(false);
            player.sendMessage(Component.text("You can Fly now").color(NamedTextColor.GREEN));
        } else {
            player.setAllowFlight(true);
            player.sendMessage(Component.text("You cant fly anymore").color(NamedTextColor.RED));
        }
        return true;

    }
}
