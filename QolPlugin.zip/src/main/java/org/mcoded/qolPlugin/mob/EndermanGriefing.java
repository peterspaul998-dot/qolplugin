package org.mcoded.qolPlugin.mob;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Enderman;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.QolPlugin;

public class EndermanGriefing implements Listener {
    private FileConfiguration config = JavaPlugin.getPlugin(QolPlugin.class).config;

    @EventHandler
    public void EnderManGriefing(EntityChangeBlockEvent e) {
        if (!config.getBoolean("mob.enderman-griefing")) return;

        if (e.getEntity() instanceof Enderman) e.setCancelled(true);
    }
}
