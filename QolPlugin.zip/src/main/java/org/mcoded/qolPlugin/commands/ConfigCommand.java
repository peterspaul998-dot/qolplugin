package org.mcoded.qolPlugin.commands;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.md_5.bungee.api.chat.BaseComponent;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.mcoded.qolPlugin.RecipeClass;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ConfigCommand implements CommandExecutor, TabCompleter {

    private final File file;
    private final FileConfiguration config;
    private final JavaPlugin plugin;;

    public ConfigCommand(File file, FileConfiguration config, JavaPlugin plugin) {
        this.config = config;
        this.file = file;
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {


        switch (args[0]) {
            case "set" -> {



                if (args.length != 3) {
                    sender.sendMessage(Component.text("Usage: /config set <path> <setting>").color(NamedTextColor.RED));
                    return false;
                }


                if (args[2].equals("true")) {
                    config.set(args[1], true);
                }
                else if (args[2].equals("false")) {
                    config.set(args[1], false);
                } else {
                    try {
                        int settingint = Integer.parseInt(args[2]);
                        config.set(args[1], settingint);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        config.set(args[1], args[2]);
                    }
                }

                sender.sendMessage(Component.text(args[1]).color(NamedTextColor.GREEN).decorate(TextDecoration.BOLD)
                                .append(Component.text(" has been set to ").decoration(TextDecoration.BOLD, false))
                        .append(Component.text(args[2]).decorate(TextDecoration.BOLD)));
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.updateCommands();
                }
            }
            case "get" -> {

            }

            case "help" -> {
                sender.sendMessage("Usage: /config <set/get/help> <path> <setting>");
                return true;
            }

        }
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String @NotNull [] args) {

        if (args.length == 1) return List.of("set", "get", "help").stream().filter(s -> s.startsWith(args[0])).toList();

        if (args.length == 3 && args[0].equals("set") && args[1].contains("commands.")) return List.of("true", "false")
                .stream().filter(s -> s.startsWith(args[2])).toList();


        return List.of();
    }
}
