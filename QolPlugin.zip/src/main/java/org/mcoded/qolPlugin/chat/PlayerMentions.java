package org.mcoded.qolPlugin.chat;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.TabCompleteEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.QolPlugin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PlayerMentions implements Listener {

    private FileConfiguration config = JavaPlugin.getPlugin(QolPlugin.class).config;

    @EventHandler
    public void onChatPlayerMention(AsyncChatEvent e) {
        Player player = e.getPlayer();

        String message = PlainTextComponentSerializer.plainText().serialize(e.message());
        Pattern pattern = Pattern.compile("@(\\w+)");
        Matcher matcher = pattern.matcher(message);

        if (!matcher.find()) return;

        if (!config.getBoolean("chat.mention-players.enabled")) {
            player.sendMessage(Component.text("Player Mentions are turned off").color(NamedTextColor.RED));
            return;
        }


        Player target = Bukkit.getPlayer(matcher.group(1));

        if (target == null) return;

        String replaced = matcher.replaceAll("<dark_purple>@" + "<bold>" + target.getName() + "<reset>");

        Component finalMessage = MiniMessage.miniMessage().deserialize(replaced);
        e.message(finalMessage);

        Component mention_message = LegacyComponentSerializer.legacyAmpersand().deserialize(config.getString
                (
                        "chat.mention-players.mentions-message","&b&l{target}&r&b has mentioned you in the Chat"

                ).replace("{target}", player.getName()));

        Bukkit.getScheduler().runTask(JavaPlugin.getPlugin(QolPlugin.class), () -> {
            switch (config.getString("chat.mention-players.show-mentions", "title")) {
                case "title" -> {
                    target.showTitle(Title.title((Component.text("You have been Mentioned!")
                            .color(NamedTextColor.DARK_PURPLE)), mention_message, 20, 100, 20));
                    return;
                }
                case "actionbar" -> {
                    target.sendActionBar(mention_message);
                    return;
                }
            }
            target.showTitle(Title.title((Component.text("You have been Mentioned!")
                    .color(NamedTextColor.DARK_PURPLE)), mention_message, 20, 100, 20));
        });
    }
}
