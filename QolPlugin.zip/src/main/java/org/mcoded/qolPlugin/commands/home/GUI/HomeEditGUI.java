package org.mcoded.qolPlugin.commands.home.GUI;

import io.papermc.paper.event.player.AsyncChatEvent;
import io.papermc.paper.event.player.ChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.mcoded.qolPlugin.QolPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;


public class HomeEditGUI implements InventoryHolder, Listener {

    private File file;
    private FileConfiguration config;
    private Inventory inv;
    private Map<UUID, Integer> setDesc = new HashMap<>();
    private Map<UUID, Integer> removeHome = new HashMap<>();
    private Map<UUID, Integer> setName = new HashMap<>();
    private Map<UUID, Integer> setIcon = new HashMap<>();
    private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);

    public HomeEditGUI(File file, FileConfiguration config) {
        this.file = file;
        this.config = config;
    }

    public void OpenGUI(Player player, int HomeNum) {
        inv = Bukkit.createInventory(this, 9 * 6, Component.text("Edit Menu"));

        for (int slot : HomeGUI.HOME_GUI.DoubleChestFrameSlots()) inv.setItem(slot, HomeGUI.HOME_GUI.frameItem(Material.BLUE_STAINED_GLASS_PANE));

        // Wenn kein home dann das
        if (config.getConfigurationSection(player.getUniqueId() + ".home" + HomeNum) == null) {
            inv.setItem(29, HomeGUI.HOME_GUI.hometemplate(HomeNum, player.getLocation(), "", null, null));
            inv.setItem(33, HomeGUI.HOME_GUI.SaveEdit(HomeNum));
        } // Wenn home dann das
         else {
            inv.setItem(29, config.getItemStack(player.getUniqueId() + ".home" + HomeNum + ".icon"));
            inv.setItem(33, HomeGUI.HOME_GUI.DeletHome(HomeNum));
        }

        inv.setItem(0, HomeGUI.HOME_GUI.BackItem());

        inv.setItem(22, HomeGUI.HOME_GUI.SetDescription(HomeNum));
        inv.setItem(20, HomeGUI.HOME_GUI.SetName(HomeNum));
        inv.setItem(24, HomeGUI.HOME_GUI.SetIcon(HomeNum));


        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getClickedInventory() == null) return;
        if (!(e.getClickedInventory().getHolder() instanceof HomeEditGUI)) return;

        Player player = (Player) e.getWhoClicked();

        ItemStack item = e.getCurrentItem();

        if (item == null) return;

        e.setCancelled(true);

        int num = 0;

        try {
            num = Integer.parseInt(item.getItemMeta().getItemName());
        } catch (NumberFormatException _) {

        }

        if (item.isSimilar(HomeGUI.HOME_GUI.BackItem())) {
            JavaPlugin.getPlugin(QolPlugin.class).getHomeSet(player).openfreshinv(player);
        }

        // Set Home Icon
        if (item.getType().equals(Material.RECOVERY_COMPASS) && item.getItemMeta().getItemModel().equals(NamespacedKey.minecraft("item_frame"))) {
            setIcon.put(player.getUniqueId(), num);
            player.sendMessage(
                    Component.text(
                            "Write the Item name in Chat. To see the Item name press F3 + H and hover over the Item to see the Item name")
                            .color(NamedTextColor.AQUA));
            player.sendMessage(Component.text("If you want to reset it write null. Or write cancel to cancel it").color(NamedTextColor.AQUA));
            player.closeInventory();
        }

        // Set Home desc
        if (item.getType().equals(Material.RECOVERY_COMPASS) && item.getItemMeta().getItemModel().equals(NamespacedKey.minecraft("anvil"))) {

            setDesc.put(player.getUniqueId(), num);
            player.sendMessage(Component.text("Write the Description in the Chat or write cancel to cancel it! If you want to reset the Description write null").color(NamedTextColor.BLUE));
            player.closeInventory();
        }

        // Set Home Name
        if (item.getType().equals(Material.RECOVERY_COMPASS) && item.getItemMeta().getItemModel().equals(NamespacedKey.minecraft("oak_sign"))) {
            setName.put(player.getUniqueId(), num);
            player.sendMessage(Component.text("Write the Name in the Chat or write cancel to cancel it! If you want to reset the Name you can write null").color(NamedTextColor.DARK_GREEN));
            player.sendMessage(Component.text("You can use <home> for the Home Number and you can use Mini Message!").color(NamedTextColor.DARK_GREEN));
            player.closeInventory();
        }

        if (item.getType().equals(Material.RECOVERY_COMPASS) && item.getItemMeta().getItemModel().equals(NamespacedKey.minecraft("red_concrete"))) {
                removeHome.put(player.getUniqueId(), num);
                player.sendMessage(Component.text("Are you sure? Write Yes or no").color(NamedTextColor.RED));
                player.closeInventory();
            }
        if (item.getType().equals(Material.RECOVERY_COMPASS) && item.getItemMeta().getItemModel().equals(NamespacedKey.minecraft("green_concrete"))) {

                config.set(player.getUniqueId() + ".home" + num + ".icon", HomeGUI.HOME_GUI.hometemplate(num, player.getLocation(), "", null, null));
                config.set(player.getUniqueId() + ".home" + num + ".loc",  player.getLocation());

                try {
                    config.save(file);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            plugin.getHomeSet(player).openfreshinv(player);
            }
        }
    @EventHandler
    public void onChat(ChatEvent e) {
        Player player = e.getPlayer();
        UUID uuid = player.getUniqueId();

        String message = PlainTextComponentSerializer.plainText().serialize(e.message());

        // Home Icon
        if (setIcon.containsKey(uuid)) {
            int home = setIcon.get(uuid);

            if (message.equalsIgnoreCase("cancel")) {
                setIcon.remove(uuid);
                e.setCancelled(true);
                player.sendMessage(Component.text("Set Icon cancelled!").color(NamedTextColor.GREEN));
                OpenGUI(player, home);
                return;
            }

            if (message.equalsIgnoreCase("null")) message = "red_bed";

            NamespacedKey key = (!message.contains("minecraft:")) ? NamespacedKey.minecraft(message) : NamespacedKey.fromString(message);

            if (config.getConfigurationSection(player.getUniqueId() + ".home" + home) != null) {
                ItemStack item = config.getItemStack(player.getUniqueId() + ".home" + home + ".icon");
                ItemMeta meta = item.getItemMeta();

                meta.setItemModel(key);

                item.setItemMeta(meta);
                config.set(player.getUniqueId() + ".home" + home + ".icon", item);
            }
            else {
                config.set(player.getUniqueId() + ".home" + home + ".icon",
                        HomeGUI.HOME_GUI.hometemplate(home, player.getLocation(), "", null, key));

                config.set(player.getUniqueId() + ".home" + home + ".loc", player.getLocation());
            }
            player.sendMessage(Component.text("Your Icon from Home " + home + " has been set to ").color(NamedTextColor.AQUA)
                    .append(Component.text(key.toString()).decorate(TextDecoration.BOLD)));
            setIcon.remove(uuid);
            e.setCancelled(true);
            OpenGUI(player, home);
        }

        // Home desc
           if (setDesc.containsKey(player.getUniqueId())) {

               int home = setDesc.get(player.getUniqueId());

               if (message.equalsIgnoreCase("cancel")) {
                   setDesc.remove(uuid);
                   e.setCancelled(true);
                   player.sendMessage(Component.text("Set Description cancelled!").color(NamedTextColor.GREEN));
                   OpenGUI(player, home);
                   return;
               }

               if (message.equalsIgnoreCase("null")) message = "";

               // Wenn home nicht da
               if (config.getConfigurationSection(player.getUniqueId() + ".home" + home) == null) {
                   config.set(player.getUniqueId() + ".home" + home + ".icon", HomeGUI.HOME_GUI.hometemplate(home, player.getLocation(), message, null, null));
                   config.set(player.getUniqueId() + ".home" + home + ".loc", player.getLocation());
               }
               // Wenn home da
               else {
                   ItemStack item = config.getItemStack(player.getUniqueId() + ".home" + home + ".icon");
                   ItemMeta meta = item.getItemMeta();

                   List<Component> lore = new ArrayList<>(meta.lore());

                   lore.set(3,
                           Component.text("Description: ")
                                   .color(NamedTextColor.DARK_GRAY)
                                   .decoration(TextDecoration.ITALIC, false)
                                   .append(
                                           Component.text(message)
                                                   .color(NamedTextColor.BLUE)
                                                   .decoration(TextDecoration.ITALIC, false)
                                   )
                   );

                   meta.lore(lore);
                   item.setItemMeta(meta);
                   config.set(player.getUniqueId() + ".home" + home + ".icon", item);
               }
               setDesc.remove(player.getUniqueId());
               player.sendMessage(Component.text("Your Description from Home " + home + " has been set to ")
                       .color(NamedTextColor.BLUE)
                       .append(Component.text(message).decorate(TextDecoration.BOLD)));
               e.setCancelled(true);
               OpenGUI(player, home);
           }

       // Home Name
                 if (setName.containsKey(uuid)) {

                     int home = setName.get(uuid);
                     if (message.equalsIgnoreCase("cancel")) {
                         setName.remove(uuid);
                         e.setCancelled(true);
                         player.sendMessage(Component.text("Set Name cancelled!").color(NamedTextColor.GREEN));
                         OpenGUI(player, home);
                         return;
                     }



                     String replaced = message
                             .replace("<home>", String.valueOf(home));

                     if (message.equalsIgnoreCase("null")) replaced = null;

                     Component HomeName = (replaced != null) ? MiniMessage.miniMessage().deserialize(replaced) : Component.text("Home " + home)
                             .decorate(TextDecoration.BOLD, TextDecoration.UNDERLINED)
                             .decoration(TextDecoration.ITALIC, false).color(NamedTextColor.AQUA);




                     if (config.getConfigurationSection(player.getUniqueId() + ".home" + home) == null) {
                         config.set(player.getUniqueId() + ".home" + home + ".icon", HomeGUI.HOME_GUI
                                 .hometemplate(home, player.getLocation(), "", HomeName, null));
                         config.set(player.getUniqueId() + ".home" + home + ".loc", player.getLocation());
                     } else {
                         ItemStack item = config.getItemStack(uuid + ".home" + home + ".icon");
                         ItemMeta meta = item.getItemMeta();

                         meta.customName(HomeName);

                         item.setItemMeta(meta);

                         config.set(player.getUniqueId() + ".home" + home + ".icon", item);
                     }
                     setName.remove(uuid);
                     player.sendMessage(Component.text("Your Name from Home " + home + " has been set to: ").color(NamedTextColor.DARK_GREEN)
                             .append(HomeName));
                     e.setCancelled(true);
                     OpenGUI(player, home);
                 }

     // Remove Home
          if (removeHome.containsKey(player.getUniqueId())) {
              int num = removeHome.get(player.getUniqueId());

              if (message.equalsIgnoreCase("yes")) {
                  config.set(player.getUniqueId() + ".home" + num, null);
                  removeHome.remove(player.getUniqueId());
                  player.sendMessage(Component.text("You have delete Home " + num).color(NamedTextColor.GREEN));
                  plugin.getHomeSet(player).openfreshinv(player);
              }
              else if (message.equalsIgnoreCase("no")) {
                  removeHome.remove(player.getUniqueId());
                  player.sendMessage(Component.text("Home deletion cancelled").color(NamedTextColor.GREEN));
                  plugin.getHomeSet(player).openfreshinv(player);
              }
              else {
                  player.sendMessage(Component.text("Please try again. Write Yes or No").color(NamedTextColor.RED));
              }
              e.setCancelled(true);
          }


           try {
               config.save(file);
           } catch (IOException e1) {
               e1.printStackTrace();
           }
    }


    @Override
    public @NotNull Inventory getInventory() {
        return inv;
    }
}
