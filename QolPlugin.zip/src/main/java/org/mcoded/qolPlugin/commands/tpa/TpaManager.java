package org.mcoded.qolPlugin.commands.tpa;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import javax.inject.Named;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class TpaManager {

    HashMap<UUID, UUID> map = new HashMap<>();

    public void request(Player player, Player target, FileConfiguration config) {

        if (!config.getBoolean(target.getUniqueId() + ".tpa")) {
            player.sendMessage(Component.text("Player has tpa disabled").color(NamedTextColor.RED).decorate(TextDecoration.BOLD));
            return;
        }


        if (config.getBoolean(target.getUniqueId() + ".tpAuto")) {
            player.teleport(target);
            target.sendMessage(Component.text(player.getName()).color(NamedTextColor.GREEN).decorate(TextDecoration.BOLD)
                    .append(Component.text(" has teleportet to you").decoration(TextDecoration.BOLD, false)));
            return;
        }

        if (player.getUniqueId().equals(target.getUniqueId())) {
            player.sendMessage(Component.text("You cant send a request to yourself").color(NamedTextColor.RED));
            return;
        }

        map.put(player.getUniqueId(), target.getUniqueId());
        target.sendMessage(Component.text(player.getName()).color(NamedTextColor.GREEN).decorate(TextDecoration.BOLD)
                .append(Component.text(" has send you a request").decoration(TextDecoration.BOLD, false)));

    }

    public void accept(Player player, Player target) {

        if (!map.containsKey(target.getUniqueId())) {
            player.sendMessage("Player has not send a request!");
            return;
        }

        if (!map.get(target.getUniqueId()).equals(player.getUniqueId())) {
            player.sendMessage("Player has not send a request!");
            return;
        }

        target.teleport(player);
        map.remove(target.getUniqueId());
    }

    public List<String> getrequest(Player player) {
        UUID uuid = player.getUniqueId();

        List<String> list = new ArrayList<>(List.of());

        for (Player target : player.getWorld().getPlayers()) {

            if (map.containsKey(target.getUniqueId()) && map.get(target.getUniqueId()).equals(uuid)) {
                list.add(target.getName());
            }
        }
        return list;
    }

    public void cancelrequest(Player player,  Player target) {
        if (!map.get(player.getUniqueId()).equals(target.getUniqueId())) {
            player.sendMessage(Component.text("You have not send the Player a request").color(NamedTextColor.RED));
            return;
        }
        map.remove(player.getUniqueId());
        target.sendMessage(Component.text(player.getName() + " has cancelled the Tpa request").color(NamedTextColor.RED));
        player.sendMessage(Component.text("You have successfully cancelled the Tpa request to " + target.getName()));
    }

}
