package org.mcoded.qolPlugin.commands;

import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.QolPlugin;


public class CommandRemove implements Listener {

    private final QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);
    private final FileConfiguration config = plugin.config;

    @EventHandler
    public void onCommand(PlayerCommandSendEvent e) {
        if (!config.getBoolean("commands.spawn"))  e.getCommands().remove("spawn");
        if (!config.getBoolean("commands.home")) e.getCommands().remove("home");
        if (!config.getBoolean("commands.tpa")) e.getCommands().remove("tpa");
        if (!config.getBoolean("commands.maintenance")) e.getCommands().remove("maintenance");
        if (!config.getBoolean("commands.ping")) e.getCommands().remove("ping");
        if (!config.getBoolean("commands.infobar")) e.getCommands().remove("infobar");


        if (!config.getBoolean("commands.staff.fly")) e.getCommands().remove("fly");
        if (!config.getBoolean("commands.staff.speed")) e.getCommands().remove("speed");
        if (!config.getBoolean("commands.staff.god")) e.getCommands().remove("god");
        if (!config.getBoolean("commands.staff.vanish")) e.getCommands().remove("vanish");
        if (!config.getBoolean("commands.staff.invsee")) e.getCommands().remove("invsee");
        if (!config.getBoolean("commands.staff.grave")) e.getCommands().remove("grave");


        if (!config.getBoolean("commands.quality.enderchest")) {
            e.getCommands().remove("enderchest");
            e.getCommands().remove("ec");
        }
        if (!config.getBoolean("commands.quality.hat")) e.getCommands().remove("hat");
        if (!config.getBoolean("commands.quality.craftingtable")) {
            e.getCommands().remove("craftingtable");
            e.getCommands().remove("crafting");
            e.getCommands().remove("craft");
        }
        if (!config.getBoolean("commands.quality.rename")) e.getCommands().remove("rename");
        if (!config.getBoolean("commands.quality.sit")) e.getCommands().remove("sit");

        e.getCommands().removeIf(commands -> commands.contains("qolplugin:"));
    }
}
