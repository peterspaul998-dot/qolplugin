package org.mcoded.qolPlugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.maintanence.MaintenanceCommand;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FiveTickClass implements Runnable {

private FileConfiguration TpaConfig;
private FileConfiguration mcConfig;
private File mcFile;
private FileConfiguration config;
private QolPlugin plugin = JavaPlugin.getPlugin(QolPlugin.class);

public FiveTickClass(FileConfiguration tpaconfig, FileConfiguration mcconfig, File mcFile, FileConfiguration conf) {
    TpaConfig = tpaconfig;
    mcConfig = mcconfig;
    this.mcFile = mcFile;
    config = conf;
}

    @Override
    public void run() {

    plugin.BossbarClass.UpdateBossbar();

        for (Player player : Bukkit.getOnlinePlayers()) {

            plugin.getHomeTp(player).stopTimer(player);

            if (!player.isOp() && mcConfig.getBoolean("maintenance") && mcConfig.getString("method").equalsIgnoreCase("kick")) {
                player.kick(Component.text("The Server is now under maintenance please wait until the Server is open").color(NamedTextColor.RED).decorate(TextDecoration.BOLD));
            }

            if (!player.isOp() && mcConfig.getBoolean("maintenance") && mcConfig.getString("method").equalsIgnoreCase("ChillWorld")) {

                if (player.getLocation().getWorld().equals(JavaPlugin.getPlugin(QolPlugin.class).chillWorld)) return;

                new MaintenanceCommand(mcConfig, mcFile, config).PlayerSave();
            }
            if (!player.isOp() && !mcConfig.getBoolean("maintenance") && player.getLocation().getWorld().equals(JavaPlugin.getPlugin(QolPlugin.class).chillWorld)) {
                new MaintenanceCommand(mcConfig, mcFile, config).SinglePlayerLoad(player);
                player.sendMessage("Test");
            }


            if (TpaConfig.getBoolean(player.getUniqueId() + ".tpAuto")) {
                for (Object ob : JavaPlugin.getPlugin(QolPlugin.class).tpaManager.getrequest(player)) {
                    Player target = Bukkit.getPlayer(ob.toString());
                    if (target == null) return;
                    JavaPlugin.getPlugin(QolPlugin.class).tpaManager.accept(player, target);
                }
            }
        }
    }
}
