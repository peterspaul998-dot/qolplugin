package org.mcoded.qolPlugin.chat;


import io.papermc.paper.connection.PlayerGameConnection;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.event.player.AsyncChatEvent;
import io.papermc.paper.event.player.PlayerCustomClickEvent;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.nbt.api.BinaryTagHolder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.mcoded.qolPlugin.QolPlugin;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HomeShare implements Listener {

    private FileConfiguration HomeConfig = JavaPlugin.getPlugin(QolPlugin.class).HomeConfig;
    private File HomeFile = JavaPlugin.getPlugin(QolPlugin.class).HomeFile;
    private FileConfiguration config = JavaPlugin.getPlugin(QolPlugin.class).config;

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player player = e.getPlayer();
        String message = PlainTextComponentSerializer.plainText().serialize(e.message());

        Pattern pattern = Pattern.compile("\\(home:(\\d+)\\)");
        Matcher matcher = pattern.matcher(message);

        if (!matcher.find()) return;

        if (!config.getBoolean("chat.home-share")) {
            player.sendMessage(Component.text("Home Share is disabled").color(NamedTextColor.RED));
            e.setCancelled(true);
            return;
        }

        if (HomeConfig.get(player.getUniqueId() + ".home" + matcher.group(1)) == null) {
            e.getPlayer().sendMessage(Component.text("You have no Home " + matcher.group(1)).color(NamedTextColor.RED));
            e.setCancelled(true);
            return;
        }

        int homeNumber = Integer.parseInt(matcher.group(1));
        String filtered = matcher.replaceAll("<light_purple>Home: " + "<bold>" + homeNumber + "<reset><light_purple>");
        Component finalMessage = MiniMessage.miniMessage().deserialize(filtered);
        e.message(finalMessage.clickEvent(ClickEvent.showDialog(openDialog(String.valueOf(homeNumber), player.getUniqueId().toString())))
                .hoverEvent(Component.text("Click to rewrite your Home")));


    }
    @EventHandler
    public void onCustomClick(PlayerCustomClickEvent e) {
        if (!(e.getCommonConnection() instanceof PlayerGameConnection connection)) return;

        Player player = connection.getPlayer();
        if (e.getIdentifier().equals(Key.key("qolplugin:homeshare/yes"))) {

            Pattern pattern = Pattern.compile(
                    "\\{number:(\\d+),player:\"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\"\\}"
            );
            Matcher matcher = pattern.matcher(e.getTag().string());
            if (!matcher.find()) {
                return;
            }
            OfflinePlayer target = Bukkit.getOfflinePlayer(UUID.fromString(matcher.group(2)));

            if (HomeConfig.get(target.getUniqueId() + ".home" + matcher.group(1)) == null) {
                player.sendMessage(Component.text(target.getName() + " has no Home " + matcher.group(1)).color(NamedTextColor.RED));
                return;
            }

            HomeConfig.set(player.getUniqueId() + ".home" + matcher.group(1), HomeConfig.get(target.getUniqueId() + ".home" + matcher.group(1)));
            try {
                HomeConfig.save(HomeFile);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            //player.sendMessage(matcher.group(2));
            player.sendMessage(Component.text("You have rewrite your Home ").color(NamedTextColor.LIGHT_PURPLE)
                    .append(Component.text(matcher.group(1)).decorate(TextDecoration.BOLD))
                    .append(Component.text(" from: "))
                    .append(Component.text(target.getName()).decorate(TextDecoration.BOLD)));
        }
    }
    public Dialog openDialog(String number, String uuid) {
        return Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text("Are you sure?").color(NamedTextColor.RED))
                        .body(List.of(
                                DialogBody.plainMessage(Component.text("Your Home will be overwritten!").color(NamedTextColor.RED))
                        )).build()
                )
                .type(DialogType.confirmation(
                        ActionButton.builder(Component.text("Okay").color(NamedTextColor.GREEN))
                                .action(DialogAction.customClick(Key.key("qolplugin:homeshare/yes"), BinaryTagHolder.binaryTagHolder("{number:" + number + ",player:\"" + uuid + "\"}")))
                                .build(),
                        ActionButton.builder(Component.text("Cancel").color(NamedTextColor.RED))
                                .action(DialogAction.customClick(Key.key("qolplugin:homeshare/no"), null)).build()
                ))
        );
    }
}
